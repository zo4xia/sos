# 下一位操作者验收清单

## 目标

只验收真实登录和组织隔离，不扩页面、不迁移旧数据、不加随机账号。

## 步骤

### 1. 确认端口和环境

```bash
cd /mnt/k/3/3/backend-new
npm run check
npm run build
```

启动 backend-new 时使用未占用随机端口，或明确确认 3100 可用。启动 web 时同样使用未占用随机端口。不要杀其他服务。

### 2. 真实 HTTP

```bash
curl -i http://127.0.0.1:<backend-port>/health
curl -i http://127.0.0.1:<backend-port>/auth/organizations
```

记录完整状态码、响应 JSON 和 CORS 响应头。

### 3. 真实浏览器

打开 web 登录页并记录：

- 组织下拉是否显示真实 active 组织。
- Network 中请求 URL 是否为 backend-new，而不是旧 `localhost:8080` 或旧 `/api/orgs`。
- 正确组织、正确账号、正确密码是否登录成功。
- token 是否写入 `localStorage`。
- 是否进入 `/election/home`。

### 4. 失败路径

- 选择 A 组织，使用 B 组织账号，确认拒绝。
- 移除 token，请求受保护数据，确认 401/拒绝。
- 登录 A 与 B 组织，分别检查首页、候选人、材料数据是否串台。

### 5. 输出要求

验收报告必须包含：

```text
命令
请求 URL
请求体（脱敏）
状态码
响应摘要
页面结果
失败路径
是否交付
```

## 禁止事项

- 不使用 Mock 作为成功证据。
- 不使用 seed-demo 代替正式迁移。
- 不以 build 通过代替浏览器验收。
- 不继续扩张页面。
