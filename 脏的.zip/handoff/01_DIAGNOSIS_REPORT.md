# 诊断报告

## 结论

当前系统不是可交付状态。代码层面：backend-new 和 web 静态检查、构建通过。产品主链层面：真实登录与组织隔离未完成验收。

## 主链

```text
归属地 organization
  + 用户 user
  + membership
  + session/token
  -> 登录上下文
  -> 组织数据查询和写入隔离
```

## 已证实

1. backend-new 独立 Neon 身份 schema 存在。
2. platform_admin 创建村/社区的真实 HTTP 链路已跑通。
3. org_admin 邀请 operator/editor/reviewer/candidate 的链路已跑通。
4. logout 会撤销 session。
5. backend-new check/build 通过。
6. web typecheck/build 通过。
7. web 登录页已调用 `/auth/organizations` 和 `/auth/admin/login`。

## 未证实

1. 浏览器能否实际取得组织列表。
2. 真实账号能否从 web 登录成功。
3. 错误 organizationId 是否稳定拒绝。
4. A 组织账号是否看不到 B 组织数据。
5. 无 token 是否被所有受保护接口拒绝。
6. 角色动作权限矩阵是否完整。
7. 非管理员角色是否有独立登录入口或应禁止后台登录。

## 直接风险

### API 路径混用

`electionApi.ts` 的认证接口已切到 backend-new，但业务读写接口仍大量使用 `/api/*`。必须逐接口确认 backend-new 是否实现，不能因登录成功就认为首页完整可用。

### Vite 代理仍指向旧后端

`web/vite.config.js` 的 `/api` 代理目标仍为 `http://localhost:8080`。当前客户端默认直连 `http://127.0.0.1:3100`，环境变量和代理不能混用而不核对。

### 登录页仍有演示痕迹

手机号、密码和平台管理选项仍有预填/注释痕迹。它们不是数据库真实存在的证明。

### seed-demo 边界

`backend-new/src/seed-demo.ts` 是测试夹具，不可作为旧系统正式业务迁移。

## 之前暴露的真实故障

浏览器曾请求旧 `/api/orgs` 并得到 500。该问题促成 API 认证和组织列表路径切换，但切换后尚未重新做浏览器闭环。

## 交付判定

当前判定：**NOT DELIVERED / 未交付**。
