# 实际变更树

```text
/mnt/k/3/3/
├── PROJECT_STATE.md
├── ENGINEERING_LOG.md
├── DECISIONS.md
├── 项目实时架构模块图.md
├── handoff/
│   ├── 00_HANDOFF_INDEX.md
│   ├── 01_DIAGNOSIS_REPORT.md
│   ├── 02_CHANGE_TREE.md
│   ├── 03_VALIDATION_EVIDENCE.md
│   ├── 04_AGENT_CONCLUSIONS.md
│   ├── 05_HISTORIAN_CONTEXT_EVIDENCE.md
│   ├── 06_NEXT_OPERATOR_CHECKLIST.md
│   ├── 07_RESOURCE_WASTE.md
│   └── 08_RUNTIME_CLEANUP.md
├── backend-new/
│   ├── .env                         [本地真实 Neon 配置，不提交]
│   ├── .env.example                 [脱敏模板]
│   ├── .gitignore
│   └── src/
│       ├── server.ts
│       ├── migrate.ts
│       └── seed-demo.ts
└── web/
    └── src/
        ├── services/electionApi.ts
        ├── pages/Login/components/Login/index.tsx
        ├── pages/Election/Home/index.tsx
        ├── pages/Election/Materials/index.tsx
        └── pages/Election/Candidates/index.tsx
```

## 已改动文件

### `/mnt/k/3/3/backend-new/.env`

已落地真实 Neon `DATABASE_URL` 和 `PORT=3100`。该文件被 `.gitignore` 忽略，不应提交。

### `/mnt/k/3/3/backend-new/.gitignore`

新增环境文件忽略规则，避免数据库凭据进入版本库。


CORS 增加 5173 来源，保留 4175 来源。

同时 `package.json` 的 `dev/start/migrate/seed:demo` 脚本统一使用 Node `--env-file=.env` 加载本地配置。


- 默认 API：`http://127.0.0.1:3100`
- `apiLogin`：`POST /auth/admin/login`
- `apiOrgs`：`GET /auth/organizations`
- health：`GET /health`
- `VITE_API_BASE_URL` 显式类型断言

### `/mnt/k/3/3/web/src/pages/Login/components/Login/index.tsx`

- 加载真实组织列表
- 按 town 分组
- 提交组织 ID、手机号、密码
- 成功保存 token 并跳转首页
- 失败显示错误

## 未变更为正式方案的内容

- 旧数据迁移
- 全量业务 API
- 完整角色权限矩阵
- 浏览器自动化验收
- 生产级邀请治理
