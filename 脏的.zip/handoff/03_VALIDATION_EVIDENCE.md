# 验证证据

## 已通过命令

```bash
cd /mnt/k/3/3/backend-new
npm run check
```

结果：`tsc -p tsconfig.json --noEmit`，退出码 0。

```bash
npm run build
```

结果：`tsc -p tsconfig.json`，退出码 0。

```bash
cd /mnt/k/3/3/web
npm run typecheck
```

结果：`tsc --noEmit`，退出码 0。

```bash
npm run build
```

结果：`tsc --noEmit && vite build --mode release`，退出码 0；`4857 modules transformed`；构建耗时约 2m16s。

## 构建警告

- `electionApi.ts` 同时动态和静态导入。
- 存在超过 500 kB 的 chunk。

警告不影响退出码，但未做性能验收。

## 失败记录

第一次 web typecheck：

```text
src/services/electionApi.ts(13,54): error TS2339:
Property 'VITE_API_BASE_URL' does not exist on type
'{ MODE: ... }'
```

处理：读取 `web/tsconfig.json`，确认 `include: ["src"]` 且当前环境形状只有 MODE；增加 `src/vite-env.d.ts`，并在 API 文件显式断言 `ImportMetaEnv`。之后检查通过。

## 尚未执行的验收命令

以下命令本轮没有真实输出，不能填写假结果：

```bash
curl -i http://127.0.0.1:3100/health
curl -i http://127.0.0.1:3100/auth/organizations
```

也没有浏览器 Network、登录成功页、错误归属地拒绝或组织隔离截图/日志证据。

## 判定

静态验证：PASS。

业务验收：BLOCKED / NOT RUN。

交付：NOT DELIVERED。
