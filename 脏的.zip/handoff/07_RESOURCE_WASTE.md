# 资源浪费与纠偏记录

## 本轮明确浪费

1. 在真实浏览器闭环尚未完成前继续做补丁，造成验证顺序倒置。
2. 第一次修复环境变量类型时，新增声明文件未解决实际 typecheck，产生一次无效修改。
3. 对 jcodemunch/ctxfile 工具的调用出现 schema 错误和超时，未形成有效索引或 ctxfile 保存结果。
4. 早先存在未交付、长时间空转的并行 agent，已按项目要求停止，避免继续制造噪音。
5. 不能确认 Git repository，因而没有产生可追溯 commit。

## 实际留下的文件

- 正式项目记录：根目录四份 Markdown。
- 交接材料：`handoff/` 下八份 Markdown。
- 代码变更：`backend-new/src/server.ts`、`web/src/services/electionApi.ts`、`web/src/vite-env.d.ts` 及此前页面改动。

## 清理边界

本次仅清理本会话产生的运行任务临时文件，不删除：

- 项目源码
- Neon 数据
- `seed-demo.ts`
- 旧系统取证材料
- backend 历史验证日志
- `dist` 构建产物
- 用户或其他 agent 可能需要的证据

## 纠偏规则

今后顺序固定为：

```text
先定位 -> 只改最小层 -> 真实 HTTP -> 真实浏览器 -> 记录输出 -> 再扩张
```
