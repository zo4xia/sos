# 村居换届选举系统 · 项目记忆（防倒退）

> **本文件是项目级硬记忆。每次新会话、每个 agent 必须先读。任何与本文件冲突的操作都是倒退。**
> 更新时间：2026-09-04

## 一、数据库真相（不许再混淆）

- **数据库是本地 PostgreSQL**：`postgresql://postgres:123456@localhost:5432/backend_new`（backend-new/.env）
- **不是 Neon**。Neon 云库有一套 155 开头/org_admin 角色的残留数据，那是旧的、错的，不要碰。
- 真实查询：`cd backend-new && node --env-file=.env _check_local.mjs`
- 旧库（含 voters/投票污染）只读封存，**不搬家、不迁移**。

## 二、角色与账号（不许再改错）

- **五角色**：`platform_admin` / `sub_admin` / `editor` / `reviewer` / `candidate`
- **没有 `org_admin`、没有 `operator`**。任何代码里出现这两个角色名都是错的。
- 真实账号（密码全部 123456）：
  - 超管：`13800000000`（演示村）
  - 演示村：`13800000001` sub_admin / `13800000002` editor / `13800000003` reviewer
  - 演示社区：`13800000011` sub_admin / `13800000012` editor / `13800000013` reviewer
  - 参选人（小程序）：`13800000021/22/23`、`13900000001`
- 演示村 orgId=`e1a318cf-dbd7-4f6c-ab2e-3c60d68affae`，演示社区 orgId=`44365f42-164c-4ea6-9f79-3363a609dd71`

## 三、铁律（违反即倒退）

1. **不能要假数据**。任何 mock/硬编码兜底都是假功能，必须删。
2. **不能有投票概念**。甲方 A-002：参选人≠选民，无线上投票。代码里出现 `voter`/`votes`/`election_results`/`cand_votes` 必须删除。
3. **后台仅超管开账号**，不允许公开注册后台账号。小程序注册只允许 candidate，且注册时选归属地后绑死。
4. **权限以后端为准**。前端禁止 localStorage 切角色、禁止前端自报身份。
5. **公告模板以甲方 DOCX 原文为准**（桌面 `村居换届倒排工期表【新增业务操作阶段映射列 公告正文模板】.docx`），不自行编造正文。
6. **提案未通过 = 不存在**。pending/rejected 的提案**不得**出现在活动列表、岗位列表、材料提交、候选人、公告等任何业务页面。只有 status=approved 的提案才触发 pipeline 生成 election_fiefs + stages + positions + announcements。
7. **阶段日期未到不得开始**。pipeline 根据 D 日倒排生成每个阶段的 start_date/end_date，报名、材料审核、候选人审核等操作必须在对应阶段日期区间内才允许执行；未到 start_date 的阶段按钮禁用/隐藏，超过 end_date 的阶段关闭。这是政务合规硬约束，不是软提示。
8. **严禁任何自动拉起/自启机制（2026-09-05 事故教训）**。不得创建 Windows 计划任务（schtasks / Register-ScheduledTask）、注册表 Run/RunOnce、Windows 服务、启动文件夹项、守护/watch 脚本（nodemon/tsx watch/forever/pm2/自写 spawn 重启器）去自动或开机拉起 dev 服务。dev 服务**只在用户当前终端手动 `npm run dev` 单次运行，关窗/结束进程即停**。曾遗留的 `election-dev-3003` 计划任务（TimeTrigger 自动拉起 E 盘旧项目 mock 前端，导致 PowerShell/黑框反复闪）与 `dev-runner.mjs` 均已删除，禁止重建。

## 四、技术主链

- 后端：`backend-new/`（Fastify，端口 3100），唯一主链
- 后台前端：`web/`（TDesign React + Vite 5，端口 3003），手术式改造不重写
- frontend-new：**弃用**
- **不使用任何崩溃自动重启/守护脚本**（dev-runner.mjs 已应用户要求删除，它会抢占端口影响其他机器）。后端手动 `npm run dev`（单次运行，改代码需手动重启），前端 `npm run dev`（仅 vite HMR 热更新，不重启服务）

## 五、web 前端现状（改造中）

- `electionApi.ts` 的 interface 全是旧库字段（`elId`/`candR1~R4`/`annCode`/`posType`/`votes`），与新库不匹配，需重写
- 接口路径全是旧的 `/api/*`，需映射到 `/admin/*`
- 详细对比见：`3_案件取证  只有这里的可相信  必看 每个字/15_web字段对比与改造清单.md`

## 六、权威来源优先级

1. 甲方 DOCX（业务定盘）
2. `3_案件取证  只有这里的可相信  必看 每个字/` 目录（14+1 个文件，项目真相）
3. 本地数据库实查（`_check_local.mjs`）
4. 后端 `server.ts` 代码现状
5. handoff/、docs/不能信/ —— 仅作线索，不可信

## 七、已知坑（踩过的，别再踩）

1. Start-Process Hidden 不持久，必须 run_in_background 或守护脚本
2. vite 改代码后需清 `node_modules/.vite` 或强制刷新
3. TDesign Select 必须用 ref 点 input，JS `.t-select.click()` 不展开
4. TDesign Select 不识别扁平 group 字段
5. 本地库(138/sub_admin)与 Neon 库(155/org_admin)是两套数据，切勿混淆
6. pg jsonb 返回对象不能再 JSON.parse
7. PowerShell here-string 内 SQL 的 `$1` 会被转义，复杂逻辑写独立 .mjs
8. web 的 `?component` SVG 导入需要内联 svgAsComponent 插件（vite.config.js），不能装只支持 vite2 的 @honkhonk/vite-plugin-svgr
9. **候选人表头日期bug**：`Candidates/index.tsx` roundHeaders 原来用 `s.review === 'R1'` 匹配，但 mergeStages 里 review 字段是空字符串，永远匹配不到。必须用 `s.key === 'prelim_shortlist'`（R1）/ `nominate_cont`（R2）/ `joint_review`（R3）/ `campaign_prep`（R4）
10. **提案附件上传**：创建提案时 onCreate 原来只提交文本字段，createFiles 和 postRows.file 完全没上传。必须在提案创建成功后遍历上传所有附件到 `/admin/proposals/:id/file`
11. **Vite proxy /admin 拦截页面路由**：vite.config.js 的 server.proxy 配置了 `/admin` → 后端，导致浏览器访问 `/admin/users` 页面路由时被代理到后端返回404 JSON。必须删除整个 proxy 配置（前端API用绝对路径不需要proxy）

## 八、本轮修复（2026-09-04）

1. **附件架构（重要，已纠正一次手搓错误）**：曾错误自造多态表 `business_files`（ref_type+ref_id 黑盒，无真实外键），已**drop 退回**。正确架构遵循 `files.ts` 原始设计注释：**统一落盘（lib.saveUploadPart 唯一收口）→ 各业务自己的强外键 `*_files` 表存 metadata**。现有四张附件表全部同构复刻 `material_files`：`material_files`（材料）/ `proposal_files`（提案）/ `announcement_files`（公告）/ `position_files`（岗位）。路由 `routes/biz-files.ts` 用一个工厂循环注册 POST `/admin/{proposals|announcements|positions}/:id/file`（multipart直传）和 GET `.../files`，代码只写一遍但表是四张明确强外键表。**严禁再搞多态统一附件表。**
2. **提案附件上传**：onCreate 成功后遍历上传提案附件+岗位报名表
3. **提案详情附件丢失修复**：根因是 mapProposal 里 `attachments: []` 写死空数组、忽略后端 p.files；后端聚合必须用 json_build_object 起驼峰别名（json_agg 原始行是下划线列名）。现已正确显示+下载
4. **候选人表头日期**：s.review→s.key，四轮审核日期全部显示
5. **候选人审核弹窗大改**：新增外部送审（mailto预填）、下载候选人信息（TXT存档）、每轮审核截止日期提示
6. **归档聚合附件**：/api/archives 把四类 *_files 全部纳入归档台账，前端按 proposal_file/announcement_file/position_file/material_file 分组、有 storageKey 可下载
7. **schema.sql 已回写为权威**：补了缺失的 election_proposals/positions 建表 + 三张业务附件表，共24表，事务验证通过
8. **字段皇榜+封地商贸地图**：18/19号HTML（取证目录，注意其中 business_files 表述已过时，以本条为准）
9. **已知遗留**：material_files 6条演示记录 storage_key=NULL（假数据，物理文件不存在，无法下载），随演示数据治理时清理或补真实文件
