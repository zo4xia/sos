/* ───────────────────────────────────────────────────────────────────────
 * notice 页 · 挖空模板骨架（待 backend-new 真实表字段反填）
 * 原 pages/notice/notice.js 仅作 data 结构参考，未改动。
 *
 * 字段映射速查（详见 _templates/TEMPLATE-GUIDE.md）：
 *   election_fief_stages.*     ← 阶段卡 / 预告 / liveStage（stage_name/status/start_date/end_date/stage_key）
 *   announcements.*             ← 公告 title/body/published_at
 *   announcement_templates.at_code ← 公告号（经 template_id）
 *   stage_templates.st_description ← 阶段说明（经模板关联）
 *   待定:公告附件 / 组织名称 / 届次选项标签 / 未读公告数 / 结果备案* ← 新主库无落点
 *   本地:当前Tab/走马灯文案/图标/材料上报窗口/是否可提交材料/各计数 ← 纯前端态
 *   🚫 红线：election_results.er_actual_voters/er_turnout/er_eligible_voters 投票人统计已删绑定；
 *            er_winner_name/er_filing_status 等非投票字段 → 待定:结果备案*
 * ─────────────────────────────────────────────────────────────────────── */

Page({
  data: {
    activeTab: 'latest',           // 本地:当前Tab
    liveStage: null,               // 详情:进行中阶段；name→election_fief_stages.stage_name
    marqueeText: null,             // 本地:走马灯文案
    todo_unreadCount: null,        // 待定:未读公告数（notifications 整表无落点）
    todo_electionOptions: null,    // 待定:届次选项列表（elections，标签含届次+名称）
    electionIndex: 0,              // 本地:届次选中索引
    todo_selectedElectionLabel: null, // 待定:届次选项标签
    stageCards: [],                // 列表:阶段卡；item.*→election_fief_stages.* + 内嵌 announcements.*
    forecasts: [],                 // 列表:日程预告；item.*→election_fief_stages.*
    history: [],                   // 列表:往届结果备案；item.*→待定:结果备案*（election_results 整表无落点）
    detail: null,                  // 详情:公告；title→announcements.title / code→at_code / content→body / publish→published_at / files→待定:公告附件
    detailKind: '',                // 本地:详情类型(ann/forecast)
    matRange: null                 // 本地:材料上报窗口文案
  },

  // TODO: 对接 backend-new /announcements（取公告 title/body/published_at/at_code）
  // TODO: 对接 backend-new /stages（取 election_fief_stages + stage_templates 说明，按 D 日反推日期）
  // TODO: 对接 backend-new /election-results（结果备案，仅非投票字段；投票人统计红线已删）

  switchTab() {},
  pickElection() {},
  openDetail() {},
  closeDetail() {},
  goMaterial() {},
  copyAnnContent() {},
  downloadAttachment() {}
})
