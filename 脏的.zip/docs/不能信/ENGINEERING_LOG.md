# 工程日志

## 2026-09-03：归属地登录垂直切片

### 目标

把 `web` 登录链路切到 `backend-new`，并保留真实组织选择与组织隔离验收入口。

### 变更文件

```text
/mnt/k/3/3/backend-new/src/server.ts
/mnt/k/3/3/web/src/services/electionApi.ts
/mnt/k/3/3/web/src/pages/Login/components/Login/index.tsx
/mnt/k/3/3/web/src/vite-env.d.ts
```

### 具体变更

1. `backend-new/src/server.ts`
   - CORS 增加 `http://localhost:5173` 和 `http://127.0.0.1:5173`。
   - 原有 `4175` 来源保留。

2. `web/src/services/electionApi.ts`
   - `apiLogin` 调用 `POST /auth/admin/login`。
   - `apiOrgs` 调用 `GET /auth/organizations`。
   - 默认 API 地址为 `http://127.0.0.1:3100`。
   - health 调用改为 `GET /health`。
   - 为兼容当前项目 TypeScript 环境，对 `VITE_API_BASE_URL` 使用 `ImportMetaEnv` 显式断言。

3. `web/src/pages/Login/components/Login/index.tsx`
   - 页面加载时请求真实组织列表。
   - 归属地按 town 分组。
   - 提交时传递 `organizationId`。
   - 成功后保存 token、同步数据并跳转首页。
   - 失败时展示错误消息。

4. `web/src/vite-env.d.ts`
   - 新增 Vite 环境变量类型声明文件。
   - 当前实际通过的是 `electionApi.ts` 中的显式类型断言，不能把单独声明文件描述成唯一修复原因。

### 验证命令与结果

```bash
cd /mnt/k/3/3/backend-new
npm run check
# 通过

npm run build
# 通过

cd /mnt/k/3/3/web
npm run typecheck
# 通过

npm run build
# 通过
# 4857 modules transformed
# vite build --mode release 退出码 0
```

### 构建警告

- `electionApi.ts` 同时被动态和静态导入，动态导入不会单独切 chunk。
- 存在超过 500 kB 的 chunk。

警告不阻塞构建，但没有做性能验收。

### 失败记录

第一次前端 typecheck 失败：

```text
src/services/electionApi.ts(13,54): error TS2339:
Property 'VITE_API_BASE_URL' does not exist on type
'{ MODE: ... }'
```

原因：当前 `tsconfig.json` 只纳入 `src`，现有环境变量类型只暴露 `MODE`。后续采用显式 `ImportMetaEnv` 类型断言后重新检查通过。

### 当前未完成

- 尚未启动新后端和新前端进行浏览器操作。
- 尚未对 `/auth/organizations`、`/auth/admin/login` 做本轮真实请求记录。
- 尚未验证组织隔离、错误归属地拒绝和无 token 拒绝。
