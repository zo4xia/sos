# Codegraph 磨盘分析报告

> 生成时间：2025-09-04  
> 工具：codegraph MCP  
> 索引文件：193 个 | 函数：746 个 | 类：76 个 | 语言：TypeScript/JavaScript

---

## 一、项目全景

### 1.1 三端架构

```
┌─────────────────────────────────────────────────────────────┐
│                     村/社区换届选举管理系统                  │
├──────────────┬──────────────────┬───────────────────────────┤
│   小程序端    │     Web 管理端    │       后端 API            │
│ miniprogram/ │     web/src/      │      backend/api.js       │
│   19 文件     │    133 文件       │       22 文件             │
│  179 函数     │    310 函数       │      130 函数             │
│   0 类       │     76 类         │        0 类               │
│  8310 行     │   12245 行        │     2293 行               │
└──────────────┴──────────────────┴───────────────────────────┘
```

### 1.2 核心目录职责

| 目录 | 职责 | 关键文件 |
|------|------|---------|
| `backend/` | Node.js 后端 API 服务（Postgres/Neon） | `api.js`（核心路由+handler） |
| `backend/scripts/` | 数据迁移、冒烟测试脚本 | 14 个脚本（含 deriveStatus 等） |
| `backend/lib/` | 后端工具函数 | 日期、文案桩等 |
| `web/src/` | React + TDesign 管理前端 | 133 个 TSX/TS 文件 |
| `web/src/pages/Election/` | 选举业务页面 | ActivityDetail、Home、Candidates 等 |
| `web/src/utils/` | 前端工具与 store | electionStore、noticeStore、request 等 |
| `web/src/layouts/` | 布局系统 | Menu、Header、AppLayout 等 |
| `web/src/modules/` | Redux 状态管理 | global、list/base/card/select、user、store |
| `web/src/services/` | API 服务层 | electionApi、product、contract |
| `miniprogram/` | 微信小程序端 | app.js、pages/*、data/* |
| `miniprogram/data/` | 小程序数据层 | db.js（本地DB）、http.js（同步）、map.js（映射） |
| `miniprogram/pages/` | 小程序页面 | home、notice、candidate、material、method、profile、login |
| `miniprogram/utils/` | 小程序工具 | api.js、dates.js、kit.js |
| `lib/` | 根目录共享工具（与 backend/lib 重复） | announcementStubText 等 |
| `scripts/` | 根目录脚本（与 backend/scripts 重复） | 14 个脚本 |

---

## 二、架构问题清单

### 2.1 🔴 高优先级问题

#### 问题 1：代码重复 — 根目录与 backend 目录内容重叠
- **现象**：`api.js`（根目录 77KB）、`lib/`、`scripts/` 在根目录和 `backend/` 下各有一份
- **影响**：维护成本翻倍，存在"两个真相"风险
- **建议**：以 `backend/` 为准，删除根目录重复副本，或用软连接隔离

#### 问题 2：循环依赖（1 处）
- **路径**：`web/src/layouts/components/Menu.tsx` → `Menu.tsx`（自引用）
- **影响**：可能导致打包异常、tree-shaking 失效
- **位置**：`Menu.tsx` 第 0 行 import 了自己

#### 问题 3：死导入泛滥（60 处）
- **总数**：60 个确认死导入 + 569 个未解析导入
- **典型案例**：
  - `TopPanel.tsx`：`Row`、`useDynamicChart` 未使用
  - `Form/Base/index.tsx`：`Row` 未使用
  - `GuideTour/index.tsx`：`LoginUser` 未使用
  - `router/index.ts`：`election`、`login` 未使用
  - `modules/global/index.ts`：`ETheme`、`insertThemeStylesheet`、`generateColorMap` 未使用
  - `layouts/components/Menu.tsx`：`Menu` 自引用（死导入+循环依赖）
- **影响**：增大打包体积，干扰代码理解
- **建议**：一轮清理，移除未使用导入

### 2.2 🟡 中优先级问题

#### 问题 4：高复杂度函数集中

**后端 `backend/api.js`**（最高复杂度 38）：
| 复杂度 | 行号 | 名称 | 等级 |
|--------|------|------|------|
| 38 | 495 | arrow_function | 极高 |
| 24 | 216 | arrow_function | 高 |
| 22 | 771 | arrow_function | 高 |
| 21 | 889 | arrow_function | 高 |
| 18 | 958 | arrow_function | 中高 |
> 大量匿名 arrow function，说明是 Express 路由 handler 内联定义，应拆分独立函数

**Web 端**：
| 复杂度 | 文件 | 函数 | 等级 |
|--------|------|------|------|
| 30 | `pages/Election/ActivityDetail/index.tsx` | `ActivityDetail` | 极高 |
| 28 | `pages/Election/Proposals/index.tsx` | `arrow_function` | 极高 |
| 12 | `pages/Election/Home/index.tsx` | `Home` | 中 |
| 12 | `pages/Election/Archives/index.tsx` | `Archives` | 中 |
| 11 | `pages/Election/Candidates/index.tsx` | `Candidates` | 中 |

**小程序端**：
| 复杂度 | 文件 | 函数 | 等级 |
|--------|------|------|------|
| 20 | `data/map.js` | `applyRule` | 高 |
| 18 | `pages/notice/notice.js` | `refresh` | 高 |
| 17 | `utils/api.js` | `success` | 中高 |
| 15 | `pages/profile/profile.js` | `refresh` | 中 |
| 15 | `data/http.js` | `syncAll` | 中 |

#### 问题 5：热点调用集中在小程序工具层

Top 5 最被调用函数（小程序端）：
1. `getToken`（miniprogram/utils/api.js）— 5 个直接调用者，29 个传递调用者
2. `request`（miniprogram/utils/api.js）— 5 个直接调用者，27 个传递调用者
3. `syncAll`（miniprogram/data/http.js）— 11 个直接调用者
4. `switchTab`（notice.js）— 11 个调用者（UI 事件）
5. `projectRows`（data/map.js）— 8 个直接调用者

> 小程序端数据层耦合度高，`syncAll` 承担全量同步，是单点风险。

#### 问题 6：命名规范不统一
- 后端字段：下划线风格（`acc_phone`、`el_org_id`）
- Web 端接口：驼峰风格（`electionId`、`orgId`）
- 小程序 DB：下划线风格（与后端一致）
- 数据映射由 `data/map.js` 的 `projectRow` 统一处理（这是好的设计）

### 2.3 🟢 低优先级 / 观察项

#### 问题 7：未解析导入数量大（569 个）
- 大量 `tdesign-react`、`react`、`echarts` 等第三方库导入无法解析（正常现象）
- 但 `hooks/useDynamicChart`、`utils/request`、`services/electionApi` 等内部别名导入也未解析
- 说明 codegraph 未配置 tsconfig 路径别名，不影响运行但影响分析精度

#### 问题 8：零测试文件
- 未发现任何 test/spec 文件
- 有冒烟测试脚本（`backend/scripts/07_api_smoke.js`），但无单元测试

---

## 三、核心数据流

### 3.1 认证流程
```
Web Login / 小程序 Login
    │
    ▼
POST /api/login (orgId + phone + password)
    │
    ▼
返回 { token, user }  →  本地存储
    │
    ▼
后续请求携带 Authorization: Bearer <token>
    │
    ▼
syncAll() 全量拉取数据 → 灌入本地 store / DB
```

### 3.2 小程序数据同步（关键路径）
```
syncAll()  [http.js]
  ├── 检查 token → 未登录直接抛 auth 错误
  ├── batch1: orgs + elections + health（并行）
  ├── 逐届拉取 stages（串行 for 循环）
  ├── batch2: announcements + positions + candidates + materials + notifications + roster + results（并行）
  ├── map.* 系列函数做字段映射
  ├── Object.assign(dbm.DB, mapped)  原位覆盖
  ├── wx.setStorageSync(CACHE_KEY, mapped)  本地缓存
  └── rerender() 通知页面刷新
```

### 3.3 Web 端状态管理
- **Redux Toolkit**：`modules/` 下 global、list、user、store
- **自定义 Store**：
  - `electionStore.ts` — 选举数据（emit 通知，6 个调用者）
  - `noticeStore.ts` — 公告数据（emit 通知，5 个调用者）
  - `roleStore.ts` — 角色权限
- **liveSync**：`utils/liveSync.ts` 实时同步机制

---

## 四、技术栈识别

| 层级 | 技术 |
|------|------|
| 后端 | Node.js + 原生 HTTP（非 Express）+ PostgreSQL (Neon) |
| Web 前端 | React 18 + TypeScript + Vite + TDesign React + Redux Toolkit + ECharts |
| 小程序 | 微信小程序原生框架（WXML/WXSS/JS） |
| 构建工具 | Vite + @vitejs/plugin-react + @honkhonk/vite-plugin-svgr |
| 图表 | ECharts + echarts-for-react |
| 路由 | react-router-dom |
| 工具库 | lodash、dayjs、axios、classnames |
| 颜色主题 | tvision-color |
| Mock | vite-plugin-mock |

---

## 五、重构优先级建议

### P0（立即处理）
1. 清理 60 个死导入（低风险高收益）
2. 修复 `Menu.tsx` 自引用循环依赖
3. 消除根目录与 `backend/` 重复代码，确立单一真相源

### P1（近期处理）
1. 拆分 `backend/api.js` 中复杂度 >20 的 handler
2. 拆分 `ActivityDetail`（复杂度 30）为子组件
3. 为 `syncAll` 增加增量同步能力，减少全量拉取

### P2（中期优化）
1. 补充核心路径单元测试（登录、数据同步、权限）
2. 统一后端与 web 端字段命名规范，消除映射成本
3. 小程序 `success` 函数（复杂度 17）拆分为多个小函数

---

## 六、模块依赖全景（外部）

```
后端依赖：pg (PostgreSQL)、dotenv
Web 依赖：react、react-dom、react-router-dom、@reduxjs/toolkit、react-redux
         tdesign-react、tdesign-icons-react、echarts、echarts-for-react
         axios、dayjs、lodash、classnames、tvision-color
         vite、@vitejs/plugin-react、vite-plugin-mock
小程序依赖：微信原生 API（wx.*）
```

---

*报告由 codegraph MCP 自动生成，数据基于 193 个索引文件的静态分析。*
