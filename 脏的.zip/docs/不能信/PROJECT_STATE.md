# 项目当前状态

更新时间：2026-09-03 23:28（本地会话记录）

## 一、结论

当前项目处于：**静态检查通过，真实业务验收未完成，不能宣称交付**。

唯一主线：

- 后端：`/mnt/k/3/3/backend-new`
- 前端：`/mnt/k/3/3/web`
- 数据库：独立 Neon
- 隔离根：`organization` + `user` + `membership` + `session`

## 二、已确认事实

### backend-new

- `npm run check` 通过。
- `npm run build` 通过。
- 已具备组织、用户、membership、session、邀请、角色及换届相关 schema 和接口。
- 已真实跑通过：平台管理员创建组织、邀请组织管理员、组织管理员邀请其他角色、注销撤销 session。
- `GET /auth/organizations` 返回 active 组织列表。
- `POST /auth/admin/login` 是当前前端管理员登录目标。

### web

- `npm run typecheck` 通过。
- `npm run build` 通过，`vite build --mode release` 退出码为 0。
- 登录页已接入归属地选择、真实组织列表加载、管理员登录、token 保存和首页跳转。
- 工作台、材料、候选人页面已接入真实加载、错误态和空态。

## 三、未证明事项

以下事项没有浏览器或真实 HTTP 验收证据，必须保持为“未证明”：

- 浏览器能否显示真实组织列表。
- 正确组织和账号能否从登录页成功登录。
- 错误归属地是否被拒绝。
- 不同组织登录后数据是否严格隔离。
- 无 token 请求是否被拒绝。
- 各角色动作权限边界是否完整正确。
- 候选人或非管理员角色是否应走其他登录入口。

## 四、当前阻塞

真实浏览器端到端验收尚未执行。不能用构建成功、seed-demo、Mock 或旧 backend 的 `/api` 响应替代验收。

## 五、明确边界

- `seed-demo.ts` 只是测试夹具，不是正式旧数据迁移。
- `backend` 仅作只读参考，不是新系统主链。
- `frontend-new` 不作为最终前端施工入口。
- 根目录当前不是 Git repository，不能声称已有 commit。
