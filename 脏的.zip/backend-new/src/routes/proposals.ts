/**
 * ── 提案模块：选举提案 / 岗位 / 审批联动（通过→建活动+日程+岗位+公告）──
 */
import type { FastifyInstance } from 'fastify';
import { z, pool, staff, requirePerm, orgScope, fiefFor, addDays, notify } from '../lib';

export async function proposalsRoutes(app: FastifyInstance) {
  // 创建提案（小编提交，超管审批；term/unit 未传时自动回填该组织 active 届 + 首个单位）
  app.post('/admin/proposals', { preHandler: requirePerm('proposal:create') }, async (req, rep) => {
    const b = z.object({ organizationId: z.string().uuid(), termId: z.string().uuid().optional(), unitId: z.string().uuid().optional(), name: z.string().min(1), dDay: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), positions: z.array(z.object({ name: z.string().min(1), quota: z.number().int().positive() })).max(10).optional() }).parse(req.body);
    if (!orgScope(b.organizationId, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    const o = (await pool!.query('select org_type from organizations where id=$1', [b.organizationId])).rows[0];
    if (!o) return rep.code(404).send({ error: 'organization_not_found' });
    let { termId, unitId } = b;
    if (!termId || !unitId) {
      const m = (await pool!.query('select (select id from election_terms where status=$1 limit 1) tid,(select id from election_units where organization_id=$2 limit 1) uid', ['active', b.organizationId])).rows[0];
      termId = termId ?? m?.tid ?? null; unitId = unitId ?? m?.uid ?? null;
    }
    // 每村可创建多个选举提案（不做 org+term 排他）
    const ps = b.positions ?? [{ name: '主任', quota: 1 }, { name: '副主任', quota: 1 }, { name: '委员', quota: 3 }, { name: '妇女成员', quota: 1 }];
    const r = await pool!.query('insert into election_proposals(organization_id,term_id,unit_id,name,d_day,org_type,positions,proposed_by) values($1,$2,$3,$4,$5,$6,$7,$8) returning *', [b.organizationId, termId, unitId, b.name, b.dDay, o.org_type, JSON.stringify(ps), req.auth!.userId]);
    return rep.code(201).send(r.rows[0]);
  });

  app.get('/admin/proposals', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ organizationId: z.string().uuid().optional() }).parse(req.query);
    const org = q.organizationId ?? req.auth!.organizationId;
    if (!orgScope(org, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    return (await pool!.query(`select p.*,o.name organization_name,
      coalesce((select json_agg(json_build_object(
        'id',pf.id,'fileName',pf.file_name,'mimeType',pf.mime_type,
        'sizeBytes',pf.size_bytes,'storageKey',pf.storage_key,'createdAt',pf.created_at
      ) order by pf.created_at) from proposal_files pf where pf.proposal_id=p.id),'[]') files
      from election_proposals p join organizations o on o.id=p.organization_id
      where p.organization_id=$1 order by p.created_at desc`, [org])).rows;
  });

  // 编辑提案（仅 pending 状态可改；已审核的禁止修改）
  app.patch('/admin/proposals/:id', { preHandler: staff }, async (req, rep) => {
    const id = z.string().uuid().parse((req.params as { id: string }).id);
    const b = z.object({ name: z.string().min(1).optional(), dDay: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(), positions: z.array(z.object({ name: z.string().min(1), quota: z.number().int().positive() })).max(10).optional() }).parse(req.body);
    const p = (await pool!.query('select * from election_proposals where id=$1', [id])).rows[0];
    if (!p) return rep.code(404).send({ error: 'proposal_not_found' });
    if (p.status !== 'pending') return rep.code(409).send({ error: 'proposal_already_reviewed' });
    if (!orgScope(p.organization_id, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    const sets: string[] = [];
    const vals: any[] = [];
    let i = 1;
    if (b.name !== undefined) { sets.push(`name=$${i}`); vals.push(b.name); i++; }
    if (b.dDay !== undefined) { sets.push(`d_day=$${i}`); vals.push(b.dDay); i++; }
    if (b.positions !== undefined) { sets.push(`positions=$${i}`); vals.push(JSON.stringify(b.positions)); i++; }
    if (!sets.length) return rep.code(400).send({ error: 'no_fields_to_update' });
    vals.push(id);
    const r = await pool!.query(`update election_proposals set ${sets.join(',')} where id=$${i} returning *`, vals);
    return r.rows[0];
  });

  // 审批：驳回→置 rejected；通过→事务内建活动+日程+岗位+公告+标记 approved
  app.post('/admin/proposals/:id/review', { preHandler: requirePerm('proposal:review') }, async (req, rep) => {
    const id = z.string().uuid().parse((req.params as { id: string }).id);
    const b = z.object({ decision: z.enum(['approved', 'rejected']), note: z.string().optional() }).parse(req.body);
    const p = (await pool!.query('select * from election_proposals where id=$1', [id])).rows[0];
    if (!p) return rep.code(404).send({ error: 'proposal_not_found' });
    if (p.status !== 'pending') return rep.code(409).send({ error: 'proposal_already_reviewed' });
    if (!orgScope(p.organization_id, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    if (b.decision === 'rejected') {
      const d = await pool!.query('update election_proposals set status=$1,reviewed_by=$2,reviewed_at=now() where id=$3 returning *', ['rejected', req.auth!.userId, id]);
      void notify(p.organization_id, `【提案审批】「${p.name}」已驳回${b.note ? ' · ' + b.note : ''}`);
      return d.rows[0];
    }
    const c = await pool!.connect();
    try {
      await c.query('begin');
      // 每村可建多个选举活动（不做届/村/单位排他）
      const orgType = p.org_type ?? 'village';
      const f = (await c.query('insert into election_fiefs(election_term_id,organization_id,unit_id,name,d_day,timezone,status,created_by) values($1,$2,$3,$4,$5,$6,$7,$8) returning *', [p.term_id, p.organization_id, p.unit_id, p.name, p.d_day, 'Asia/Shanghai', 'active', req.auth!.userId])).rows[0];
      const templates = (await c.query('select * from stage_templates where active=true and org_type=$1 order by st_order', [orgType])).rows;
      for (const t of templates) await c.query('insert into election_fief_stages(election_fief_id,stage_template_id,stage_key,stage_name,start_date,end_date,stage_order) values($1,$2,$3,$4,$5,$6,$7)', [f.id, t.id, t.st_key, t.st_name, addDays(p.d_day, t.st_day_offset), addDays(p.d_day, t.st_duration_days), t.st_order]);
      const appStart = addDays(p.d_day, -15), appEnd = addDays(p.d_day, -13);
      const positions = typeof p.positions === 'string' ? JSON.parse(p.positions) : p.positions;
      for (const po of positions) await c.query('insert into positions(election_fief_id,name,quota,application_start,application_end,material_review_start,material_review_end) values($1,$2,$3,$4,$5,$6,$7)', [f.id, po.name, po.quota, appStart, appEnd, appStart, appEnd]);
      const ats = await c.query('select * from announcement_templates where active=true and at_sched_offset is not null order by at_sched_offset');
      let pub = 0;
      for (const a of ats.rows) {
        const d = addDays(p.d_day, a.at_sched_offset);
        const title = orgType === 'community' ? a.at_name.replace('村民', '居民') : a.at_name;
        const body = orgType === 'community' ? a.at_content.replace(/村民/g, '居民').replace(/村/g, '社区').replace(/乡镇/g, '街道').replace(/党委/g, '党工委') : a.at_content;
        await c.query('insert into announcements(election_fief_id,title,body,template_id,created_by,updated_by,scheduled_for) values($1,$2,$3,$4,$5,$5,$6)', [f.id, title, body, a.id, req.auth!.userId, d]);
        pub++;
      }
      await c.query('update election_proposals set status=$1,reviewed_by=$2,reviewed_at=now() where id=$3', ['approved', req.auth!.userId, id]);
      await c.query('commit');
      void notify(p.organization_id, `【提案审批】「${p.name}」已通过，选举活动已启动（${p.d_day}）`);
      return rep.code(201).send({ fiefId: f.id, stages: templates.length, positions: positions.length, announcements: pub, dDay: p.d_day, orgType });
    } catch (e) { await c.query('rollback'); if ((e as { code?: string }).code === '23505') return rep.code(409).send({ error: 'election_fief_already_exists' }); throw e; } finally { c.release(); }
  });

  // 岗位
  app.get('/admin/positions', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionFiefId: z.string().uuid() }).parse(req.query);
    const f = await fiefFor(q.electionFiefId, req, rep); if (!f) return;
    return (await pool!.query('select * from positions where election_fief_id=$1 order by application_start,created_at', [f.id])).rows;
  });
  app.get('/candidate/positions', { preHandler: requirePerm('candidate') }, async (req) => {
    return (await pool!.query('select p.id,p.name,p.quota,p.status,p.application_start,p.application_end,p.material_review_start,p.material_review_end from positions p join election_fiefs f on f.id=p.election_fief_id where f.organization_id=$1 order by p.name', [req.auth!.organizationId])).rows;
  });

  // web 兼容 /api 口径（旧字段名封装）
  app.get('/api/positions', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionId: z.string().uuid().optional(), orgId: z.string().uuid().optional() }).parse(req.query);
    const org = q.orgId ?? req.auth!.organizationId;
    const rows = (await pool!.query(`
      select p.id,f.organization_id as "orgId",p.election_fief_id as "elId",
             p.name as "posType",p.quota as "posQuota",p.status as "posStatus"
      from positions p
      join election_fiefs f on f.id=p.election_fief_id
      where ($1::uuid is null or f.id=$1) and ($2::uuid is null or f.organization_id=$2)
      order by p.application_start,p.created_at
    `, [q.electionId ?? null, orgScope(org, req) ? org : req.auth!.organizationId])).rows;
    return { code: 0, data: rows };
  });
}
