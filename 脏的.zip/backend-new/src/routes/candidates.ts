/**
 * ── 候选人模块：候选人池 + 轮次审核（R1~R4）──
 * 驳回不推进轮次：仅置 status='rejected'（current_round 约束只允许 R1~R4/complete）
 */
import type { FastifyInstance } from 'fastify';
import { z, pool, staff, requirePerm, orgScope, fiefFor, notify } from '../lib';

export async function candidatesRoutes(app: FastifyInstance) {
  app.get('/admin/candidates', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionFiefId: z.string().uuid() }).parse(req.query);
    const f = await fiefFor(q.electionFiefId, req, rep); if (!f) return;
    return (await pool!.query('select c.*,u.display_name,coalesce(json_agg(cr order by cr.created_at) filter (where cr.id is not null),\'[]\') reviews from candidates c join users u on u.id=c.user_id left join candidate_reviews cr on cr.candidate_id=c.id where c.election_fief_id=$1 group by c.id,u.display_name order by c.created_at', [f.id])).rows;
  });

  app.post('/admin/candidates/:id/reviews', { preHandler: requirePerm('candidate:review') }, async (req, rep) => {
    const id = z.string().uuid().parse((req.params as { id: string }).id);
    const b = z.object({ round: z.enum(['R1', 'R2', 'R3', 'R4']), decision: z.enum(['approved', 'rejected']), note: z.string().optional() }).parse(req.body);
    const r = (await pool!.query('select c.current_round,c.status,ef.organization_id from candidates c join election_fiefs ef on ef.id=c.election_fief_id where c.id=$1', [id])).rows[0];
    if (!r) return rep.code(404).send({ error: 'candidate_not_found' });
    if (!orgScope(r.organization_id, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    if (r.current_round !== b.round) return rep.code(409).send({ error: 'review_round_out_of_order' });
    await pool!.query('insert into candidate_reviews(candidate_id,round,reviewer_id,decision,note) values($1,$2,$3,$4,$5)', [id, b.round, req.auth!.userId, b.decision, b.note]);
    const rejected = b.decision === 'rejected';
    void notify(r.organization_id, `【候选人${b.round}】候选人第${b.round[1]}轮审核${b.decision === 'approved' ? '通过' : '驳回'}${b.note ? ' · ' + b.note : ''}`);
    return (await pool!.query('update candidates set current_round=$1,status=$2 where id=$3 returning *', [rejected ? b.round : b.round === 'R4' ? 'complete' : `R${Number(b.round[1]) + 1}`, rejected ? 'rejected' : b.round === 'R4' ? 'approved' : 'reviewing', id])).rows[0];
  });

  // web 兼容 /api 口径（旧字段名封装，candR1~R4 从 reviews 平铺）
  app.get('/api/candidates', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionId: z.string().uuid().optional(), orgId: z.string().uuid().optional() }).parse(req.query);
    const org = q.orgId ?? req.auth!.organizationId;
    const rows = (await pool!.query(`
      select c.id,f.organization_id as "orgId",c.election_fief_id as "elId",
             u.display_name as "candName",u.phone as "candPhone",c.status as "candStatus",
             c.current_round as "candCurrentRound",
             coalesce(json_agg(cr order by cr.created_at) filter (where cr.id is not null),'[]') as reviews,
             coalesce((
               select json_agg(json_build_object(
                 'id', m.id, 'title', m.title, 'status', m.status,
                 'submittedAt', m.submitted_at, 'reviewNote', m.review_note,
                 'files', (select coalesce(json_agg(mf order by mf.created_at),'[]')
                           from material_files mf where mf.material_id=m.id)
               ) order by m.submitted_at)
               from materials m where m.candidate_user_id=c.user_id
             ),'[]') as materials
      from candidates c
      join users u on u.id=c.user_id
      join election_fiefs f on f.id=c.election_fief_id
      left join candidate_reviews cr on cr.candidate_id=c.id
      where ($1::uuid is null or f.id=$1) and ($2::uuid is null or f.organization_id=$2)
      group by c.id,u.display_name,u.phone,f.organization_id
      order by c.created_at
    `, [q.electionId ?? null, orgScope(org, req) ? org : req.auth!.organizationId])).rows;
    // 平铺 R1~R4
    const flat = rows.map((r: any) => {
      const out: any = { id: r.id, orgId: r.orgId, elId: r.elId, candName: r.candName, candPhone: r.candPhone, candStatus: r.candStatus, candCurrentRound: r.candCurrentRound };
      for (const rv of r.reviews || []) {
        const k = rv.round; // R1/R2/R3/R4
        out[`cand${k}`] = rv.decision === 'approved' ? '通过' : rv.decision === 'rejected' ? '不通过' : '';
        out[`cand${k}Comment`] = rv.note || '';
        out[`cand${k}Time`] = rv.created_at;
      }
      return out;
    });
    return { code: 0, data: flat };
  });
}
