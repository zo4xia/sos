/**
 * ── 公告模块：公告 / 模板 / 发布 / 候选人口径 + web 兼容 /api 口径 ──
 */
import type { FastifyInstance } from 'fastify';
import { z, pool, staff, roleGuard, requirePerm, orgScope, fiefFor, notify } from '../lib';

export async function announcementsRoutes(app: FastifyInstance) {
  // 创建公告（模板 or 手写）
  app.post('/admin/announcements', { preHandler: staff }, async (req, rep) => {
    const b = z.object({ electionFiefId: z.string().uuid(), title: z.string().min(1).optional(), body: z.string().min(1).optional(), templateCode: z.string().min(1).optional(), templateVersion: z.string().optional() }).refine(v => v.templateCode || v.title && v.body, { message: 'title_body_or_template_required' }).parse(req.body);
    const f = await fiefFor(b.electionFiefId, req, rep); if (!f) return;
    const t = b.templateCode ? (await pool!.query('select id,at_name,at_content from announcement_templates where at_code=$1 and at_version=$2 and active=true', [b.templateCode, b.templateVersion ?? '通用'])).rows[0] : undefined;
    if (b.templateCode && !t) return rep.code(404).send({ error: 'announcement_template_not_found' });
    return rep.code(201).send((await pool!.query('insert into announcements(election_fief_id,title,body,template_id,created_by,updated_by) values($1,$2,$3,$4,$5,$5) returning *', [f.id, b.title ?? t.at_name, b.body ?? t.at_content, t?.id ?? null, req.auth!.userId])).rows[0]);
  });
  app.patch('/admin/announcements/:id', { preHandler: staff }, async (req, rep) => {
    const id = z.string().uuid().parse((req.params as { id: string }).id);
    const b = z.object({ title: z.string().min(1), body: z.string().min(1) }).parse(req.body);
    const r = (await pool!.query('select a.*,f.organization_id from announcements a join election_fiefs f on f.id=a.election_fief_id where a.id=$1', [id])).rows[0];
    if (!r) return rep.code(404).send({ error: 'announcement_not_found' });
    if (!orgScope(r.organization_id, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    if (r.status === 'published') return rep.code(409).send({ error: 'announcement_already_published' });
    return (await pool!.query('update announcements set title=$1,body=$2,updated_by=$3,updated_at=now() where id=$4 returning *', [b.title, b.body, req.auth!.userId, id])).rows[0];
  });
  app.post('/admin/announcements/:id/publish', { preHandler: requirePerm('announcement:publish') }, async (req, rep) => {
    const id = z.string().uuid().parse((req.params as { id: string }).id);
    const r = (await pool!.query('select a.status,f.organization_id from announcements a join election_fiefs f on f.id=a.election_fief_id where a.id=$1', [id])).rows[0];
    if (!r) return rep.code(404).send({ error: 'announcement_not_found' });
    if (!orgScope(r.organization_id, req)) return rep.code(403).send({ error: 'organization_mismatch' });
    if (r.status === 'published') return rep.code(409).send({ error: 'announcement_already_published' });
    const a = await pool!.query("update announcements set status='published',published_by=$1,published_at=now(),updated_by=$1,updated_at=now() where id=$2 and status='draft' returning *", [req.auth!.userId, id]);
    void notify(r.organization_id, `【公告发布】《${a.rows[0]?.title ?? ''}》已发布`);
    return a.rows[0];
  });

  app.get('/admin/announcements', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionFiefId: z.string().uuid() }).parse(req.query);
    const f = await fiefFor(q.electionFiefId, req, rep); if (!f) return;
    return (await pool!.query('select a.*,t.at_name template_name,t.at_code template_code from announcements a left join announcement_templates t on t.id=a.template_id where a.election_fief_id=$1 order by a.scheduled_for nulls last,a.created_at', [f.id])).rows;
  });
  app.get('/admin/announcement-templates', { preHandler: staff }, async () => {
    return (await pool!.query('select * from announcement_templates where active=true order by at_code')).rows;
  });

  // 候选人口径（仅 published）
  app.get('/candidate/announcements', { preHandler: roleGuard('candidate') }, async (req) => {
    return (await pool!.query("select a.id,a.title,a.body,a.status,a.published_at,a.stage_key,t.at_code from announcements a left join announcement_templates t on t.id=a.template_id join election_fiefs f on f.id=a.election_fief_id where f.organization_id=$1 and a.status='published' order by a.published_at desc nulls last", [req.auth!.organizationId])).rows;
  });

  // web 兼容 /api 口径
  app.get('/api/announcements', { preHandler: staff }, async (req, rep) => {
    const q = z.object({ electionId: z.string().uuid().optional(), orgId: z.string().uuid().optional() }).parse(req.query);
    const org = q.orgId ?? req.auth!.organizationId;
    const rows = (await pool!.query(`
      select a.id,f.organization_id as "orgId",a.election_fief_id as "elId",
             coalesce(t.at_code,'ANN-00') as "annCode",a.title as "annTitle",
             'stage_1' as "annStageKey",a.status as "annStatus",
             a.body as "annContent",a.published_at as "annPublishTime"
      from announcements a
      join election_fiefs f on f.id=a.election_fief_id
      left join announcement_templates t on t.id=a.template_id
      where ($1::uuid is null or f.id=$1) and ($2::uuid is null or f.organization_id=$2)
      order by a.created_at desc
    `, [q.electionId ?? null, orgScope(org, req) ? org : req.auth!.organizationId])).rows;
    return { code: 0, data: rows };
  });
}
