import { createHash, randomBytes, scrypt as scryptCallback } from 'node:crypto';
import { promisify } from 'node:util';
import { Pool } from 'pg';

const scrypt = promisify(scryptCallback);
const databaseUrl = process.env.DATABASE_URL;
const demoPassword = process.env.DEMO_PASSWORD;
if (!databaseUrl) throw new Error('DATABASE_URL is required');
if (!demoPassword || demoPassword.length < 8) throw new Error('DEMO_PASSWORD must be at least 8 characters');

const hash = (value: string) => createHash('sha256').update(value).digest('hex');
async function passwordHash(password: string) {
  const salt = randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, 64) as Buffer;
  return `scrypt:${salt}:${key.toString('hex')}`;
}

const pool = new Pool({ connectionString: databaseUrl, max: 1 });
const organizations = [
  { slug: 'demo-village', name: '演示村' },
  { slug: 'demo-community', name: '演示社区' },
];
const roles = [
  { role: 'org_admin', label: '组织管理员' },
  { role: 'operator', label: '业务经办' },
  { role: 'editor', label: '公告编辑' },
  { role: 'reviewer', label: '材料审核' },
  { role: 'candidate', label: '参选人' },
] as const;

try {
  const client = await pool.connect();
  try {
    await client.query('begin');
    const existingTerm = (await client.query(
      "select id from election_terms where name='2026基层换届演示届次' order by created_at limit 1",
    )).rows[0];
    const term = existingTerm ?? (await client.query(
      "insert into election_terms(name,status) values('2026基层换届演示届次','active') returning id",
    )).rows[0];
    const result: Array<{ organization: string; phone: string; role: string }> = [];

    for (const organization of organizations) {
      const org = (await client.query(
        `insert into organizations(slug,name,status) values($1,$2,'active')
         on conflict (slug) do update set name=excluded.name, status='active'
         returning id, slug`,
        [organization.slug, organization.name],
      )).rows[0];
      const unit = (await client.query(
        `insert into election_units(organization_id,name) values($1,$2)
         on conflict (organization_id,name) do update set name=excluded.name
         returning id`,
        [org.id, organization.name],
      )).rows[0];

      if (organization.slug === 'demo-village') {
        const platformAdmin = (await client.query(
          `insert into users(phone,password_hash,display_name) values($1,$2,$3)
           on conflict (phone) do update set display_name=excluded.display_name,status='active'
           returning id`,
          ['15500000001', await passwordHash(demoPassword), '换届系统超管'],
        )).rows[0];
        await client.query(
          `insert into memberships(user_id,organization_id,role) values($1,$2,'platform_admin')
           on conflict (user_id) do update set organization_id=excluded.organization_id,role='platform_admin'`,
          [platformAdmin.id, org.id],
        );
        result.push({ organization: 'platform', phone: '15500000001', role: 'platform_admin' });
      }

      const accounts: Record<string, string> = {};
      for (const [index, item] of roles.entries()) {
        const phone = `155000${organization.slug === 'demo-village' ? '1' : '2'}${String(index + 1).padStart(4, '0')}`;
        const user = (await client.query(
          `insert into users(phone,password_hash,display_name) values($1,$2,$3)
           on conflict (phone) do update set display_name=excluded.display_name,status='active'
           returning id`,
          [phone, await passwordHash(demoPassword), `${organization.name}${item.label}`],
        )).rows[0];
        await client.query(
          `insert into memberships(user_id,organization_id,role) values($1,$2,$3)
           on conflict (user_id) do update set organization_id=excluded.organization_id,role=excluded.role`,
          [user.id, org.id, item.role],
        );
        accounts[item.role] = user.id;
        result.push({ organization: organization.slug, phone, role: item.role });
      }

      const fief = (await client.query(
        `insert into election_fiefs(election_term_id,organization_id,unit_id,name,d_day,timezone,status,created_by)
         values($1,$2,$3,$4,'2026-12-20','Asia/Shanghai','active',$5)
         on conflict (election_term_id,organization_id,unit_id) do update
           set name=excluded.name,status='active'
         returning id`,
        [term.id, org.id, unit.id, `${organization.name}换届演示`, accounts.org_admin],
      )).rows[0];
      const templates = (await client.query('select * from stage_templates where active=true order by st_order')).rows;
      for (const template of templates) {
        await client.query(
          `insert into election_fief_stages(election_fief_id,stage_template_id,stage_key,stage_name,start_date,end_date,stage_order)
           values($1,$2,$3,$4,('2026-12-20'::date + ($5::int)),('2026-12-20'::date + ($6::int)),$7)
           on conflict (election_fief_id,stage_key) do update set
             stage_name=excluded.stage_name,start_date=excluded.start_date,end_date=excluded.end_date,stage_order=excluded.stage_order`,
          [fief.id, template.id, template.st_key, template.st_name, template.st_day_offset, template.st_duration_days, template.st_order],
        );
      }
    }
    await client.query('commit');
    console.log(JSON.stringify({
      organizations: organizations.map(({ slug, name }) => ({ slug, name })),
      term: '2026基层换届演示届次',
      accounts: result,
    }));
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally {
    client.release();
  }
} finally {
  await pool.end();
}
