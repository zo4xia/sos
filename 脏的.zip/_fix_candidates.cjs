const fs = require('fs');
const p = 'web/src/pages/Election/Candidates/index.tsx';
let t = fs.readFileSync(p, 'utf8');

// 1. 注释掉邮件相关 state（第115-121行附近）
t = t.replace(
  /\/\/ 一键送审邮件[\s\S]*?const \[mailBusy, setMailBusy\] = useState\(false\);/,
  '// 一键送审邮件已禁用：后端无 SMTP 接口\n  // const [mailOpen, setMailOpen] = useState(false);\n  // const [mailRound, setMailRound] = useState(1);\n  // const [mailEmails, setMailEmails] = useState(() => localStorage.getItem(\'cxq_review_emails\') || \'\');\n  // const [mailNote, setMailNote] = useState(\'\');\n  // const [mailResult, setMailResult] = useState(null);\n  // const [mailBusy, setMailBusy] = useState(false);'
);

// 2. 注释掉 sendMail 函数
t = t.replace(
  /const sendMail = async \(\) => \{[\s\S]*?\n  \};/,
  '// sendMail 已禁用：后端无 SMTP 接口'
);

// 3. 改 putCandidateRound 调用参数
t = t.replace(
  /const r = await putCandidateRound\(cand\.id, \(roundIdx \+ 1\) as 1 \| 2 \| 3 \| 4, result, reason\.trim\(\) \|\| undefined\);/,
  'const roundKey = (\'R\' + (roundIdx + 1)) as \'R1\' | \'R2\' | \'R3\' | \'R4\';\n      const decision = result === \'通过\' ? \'approved\' : \'rejected\';\n      const r = await putCandidateRound(cand.id, roundKey, decision, reason.trim() || undefined);'
);

// 4. 改 r.candStatus → r.status（后端返回 status）
t = t.replace(/状态：\$\{r\.candStatus\}/, '状态：${r.status}');

// 5. 注释掉邮件按钮
t = t.replace(
  /<Button size='small' theme='primary' variant='outline' onClick=\{\(\) => \{ setMailOpen\(true\); setMailResult\(null\); \}\}>[\s\S]*?<\/Button>/,
  '{/* 一键送审邮箱已禁用：后端无 SMTP */}'
);

// 6. 注释掉邮件弹窗（从 {/* 一键送审邮件 */} 到对应 </Dialog>）
t = t.replace(
  /\{\/\* 一键送审邮件 \*\/\}[\s\S]*?<\/Dialog>\n\n      \{\/\* 四轮审核详情/,
  '{/* 一键送审邮件已禁用：后端无 SMTP */}\n\n      {/* 四轮审核详情'
);

// 7. 去掉得票列
t = t.replace(
  /\{ colKey: 'votes', title: '得票', width: 70, cell: \(\{ row \}\) => row\.votes \?\? '—' \},/,
  '// 得票列已删除：甲方 A-002 禁止投票概念'
);

// 8. 去掉详情里的得票显示
t = t.replace(
  /\{detail\.votes != null && \([\s\S]*?\)\}/,
  '{/* 得票显示已删除：甲方 A-002 禁止投票概念 */}'
);

// 9. 去掉 list map 里的 votes
t = t.replace(/votes: c\.candVotes,/, '// votes 已删除：甲方 A-002 禁止投票概念');

fs.writeFileSync(p, t, 'utf8');
console.log('Candidates/index.tsx 已修复');
