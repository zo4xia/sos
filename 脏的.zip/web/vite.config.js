import path from 'path';
import fs from 'node:fs';
import { loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

const CWD = process.cwd();

// 内联插件：把 `xxx.svg?component` 转成 React 组件（替代只支持 vite2 的 @honkhonk/vite-plugin-svgr，兼容 vite5，零新增依赖）
const svgAsComponent = {
  name: 'svg-as-component',
  enforce: 'pre',
  transform(_code, id) {
    if (!id.includes('.svg?component')) return null;
    const file = id.split('?')[0];
    const svg = fs.readFileSync(file, 'utf8');
    return {
      code: `import React from 'react';
const Svg=(props)=>React.createElement('span',Object.assign({style:{display:'inline-flex',lineHeight:0}},props,{dangerouslySetInnerHTML:{__html:${JSON.stringify(svg)}}}));
export default Svg;`,
      map: null,
    };
  },
};

export default (params) => {
  const { mode } = params;
  const { VITE_BASE_URL } = loadEnv(mode, CWD);

  return {
    base: VITE_BASE_URL,
    resolve: {
      alias: {
        assets: path.resolve(__dirname, './src/assets'),
        components: path.resolve(__dirname, './src/components'),
        configs: path.resolve(__dirname, './src/configs'),
        layouts: path.resolve(__dirname, './src/layouts'),
        modules: path.resolve(__dirname, './src/modules'),
        pages: path.resolve(__dirname, './src/pages'),
        styles: path.resolve(__dirname, './src/styles'),
        utils: path.resolve(__dirname, './src/utils'),
        services: path.resolve(__dirname, './src/services'),
        router: path.resolve(__dirname, './src/router'),
        hooks: path.resolve(__dirname, './src/hooks'),
        types: path.resolve(__dirname, './src/types'),
      },
    },

    css: {
      preprocessorOptions: {
        less: {
          modifyVars: {
            // 如需自定义组件其他 token, 在此处配置
          },
        },
      },
    },

    plugins: [
      svgAsComponent,
      react(),
    ],

    build: {
      cssCodeSplit: false,
    },

    preview: {
      host: '0.0.0.0',
      port: 3005,
    },
    server: {
      host: '0.0.0.0',
      port: 3003,
    },
  };
};
