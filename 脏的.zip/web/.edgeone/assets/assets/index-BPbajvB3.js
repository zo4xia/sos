import{D as o}from"./Dialog-B08CezTv.js";import"./index-B-6IPBx2.js";/**
 * tdesign v1.18.2
 * (c) 2026 tdesign
 * @license MIT
 */var i=o;export{i as D};
