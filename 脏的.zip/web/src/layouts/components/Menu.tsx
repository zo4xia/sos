import React, { memo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu } from 'tdesign-react';
import { MENU_CONFIG } from 'configs/menu';
import { useAppSelector } from 'modules/store';
import { selectGlobal } from 'modules/global';
import { currentUser } from 'services/electionApi';
import MenuLogo from './MenuLogo';
import Style from './Menu.module.less';

const { SubMenu, MenuItem, HeadMenu } = Menu;

/** 按当前用户角色过滤菜单：子项声明了 roles 且当前角色不在其中则隐藏 */
const filterByRole = <T extends { roles?: string[] }>(items: T[]): T[] => {
  const role = currentUser()?.role;
  return items.filter((it) => !it.roles || !role || it.roles.includes(role));
};

interface IMenuProps {
  showLogo?: boolean;
  showOperation?: boolean;
}

/**
 * 顶部菜单（基于菜单配置平铺一级）
 */
export const HeaderMenu = memo(() => {
  const globalState = useAppSelector(selectGlobal);
  const location = useLocation();
  const navigate = useNavigate();

  const topItems = MENU_CONFIG.flatMap((g) => g.items);

  return (
    <HeadMenu
      expandType='popup'
      style={{ marginBottom: 20 }}
      value={location.pathname}
      theme={globalState.theme}
      onChange={(v) => navigate(String(v))}
    >
      {topItems.map((item) => (
        <MenuItem
          key={item.path}
          value={item.path}
          icon={<span className={Style.menuIcon}>{item.icon}</span>}
          onClick={() => navigate(item.path)}
        >
          {item.title}
        </MenuItem>
      ))}
    </HeadMenu>
  );
});

/**
 * 左侧菜单：照「村长仪表盘」靶子结构 —— 分组标签 + 一级(emoji) + 子菜单
 */
export default memo((props: IMenuProps) => {
  const location = useLocation();
  const globalState = useAppSelector(selectGlobal);
  const navigate = useNavigate();

  const { version } = globalState;
  const bottomText = globalState.collapsed ? version : `城厢区换届选举系统 v${version}`;

  // Keep parent menus open/active for detail routes without coupling navigation
  // to permissions or business-page state.
  const activePath = location.pathname;

  const renderItem = (item: (typeof MENU_CONFIG)[number]['items'][number]) => {
    const children = item.children ? filterByRole(item.children) : [];
    if (!item.children || children.length === 0) {
      return (
        <MenuItem
          key={item.path}
          value={item.path}
          icon={<span className={Style.menuIcon}>{item.icon}</span>}
          onClick={() => navigate(item.path)}
        >
          {item.title}
        </MenuItem>
      );
    }
    return (
      <SubMenu
        key={item.path}
        value={item.path}
        title={item.title}
        icon={<span className={Style.menuIcon}>{item.icon}</span>}
      >
        {children.map((child) => (
          <MenuItem key={child.path} value={child.path} onClick={() => navigate(child.path)}>
            {child.title}
          </MenuItem>
        ))}
      </SubMenu>
    );
  };

  return (
    <Menu
      width='232px'
      style={{ flexShrink: 0, height: '100%' }}
      className={Style.menuPanel2}
      value={activePath}
      theme={globalState.theme}
      collapsed={globalState.collapsed}
      operations={props.showOperation ? <div className={Style.menuTip}>{bottomText}</div> : undefined}
      logo={props.showLogo ? <MenuLogo collapsed={globalState.collapsed} /> : undefined}
    >
      {MENU_CONFIG.map((group, gi) => (
        <React.Fragment key={gi}>
          {group.label ? <div className={Style.groupLabel}>{group.label}</div> : null}
          {group.items.map(renderItem)}
        </React.Fragment>
      ))}
    </Menu>
  );
});
