/**
 * 角色权限 store —— 唯一数据源：后端 roles / role_permissions 表（GET /admin/roles）
 * 对齐案件取证 07 号：前端不冒充后端身份，无任何本地假数据/降级伪造角色。
 * 加载失败宁可有限重试，也不写死角色；页面按真实权限点控制关键按钮显隐，
 * 写操作（审核/发布/审批/建账号）由后端 requirePerm 静默验证兜底（403 时前端提示）。
 */
import { useSyncExternalStore } from 'react';
import { getRoles as fetchRoles, type RoleDTO } from '../services/electionApi';

export interface Role {
  /** 后端主键 role_key（platform_admin/sub_admin/editor/reviewer/candidate） */
  key: string;
  name: string;
  note?: string;
  is_staff: boolean;
  is_system: boolean;
  /** 后端真实权限点（17 条「资源:动作」，如 proposal:create / proposal:review） */
  permissions: string[];
}

const EMPTY: Role = { key: '', name: '', is_staff: false, is_system: false, permissions: [] };

let roles: Role[] = [];
let currentRole: Role = EMPTY;
let loaded = false;
let roleLoadAttempts = 0;

/** 从登录态(cxq_user.role)匹配当前角色；无登录态返回空角色（不伪造） */
function pickCurrent(list: Role[]): Role {
  let roleKey = '';
  try {
    const saved = localStorage.getItem('cxq_user');
    if (saved) roleKey = JSON.parse(saved).role || '';
  } catch {
    /* ignore */
  }
  if (roleKey) {
    const found = list.find((r) => r.key === roleKey);
    if (found) return found;
  }
  return list[0] || EMPTY;
}

const listeners = new Set<() => void>();
function emit() {
  listeners.forEach((l) => l());
}

/** 拉取后端角色（模块加载自动触发；失败有限重试，不降级伪造角色） */
export async function loadRolesFromBackend() {
  try {
    const list = (await fetchRoles()) as RoleDTO[];
    if (!list || !list.length) throw new Error('empty roles');
    roles = list.map((r) => ({
      key: r.key,
      name: r.name,
      note: r.note,
      is_staff: r.is_staff,
      is_system: r.is_system,
      permissions: r.permissions || [],
    }));
    currentRole = pickCurrent(roles);
    loaded = true;
    roleLoadAttempts = 0;
    emit();
  } catch {
    /* 后端不可用：维持空角色；有限重试规避后端冷启动时序 */
    roleLoadAttempts += 1;
    if (roleLoadAttempts <= 3) setTimeout(() => void loadRolesFromBackend(), 1500);
  }
}

export function getRoles(): Role[] {
  return roles;
}

export function getCurrentRole(): Role {
  return currentRole;
}

/** 当前登录角色是否拥有指定权限点（如 'proposal:review'）；未加载完成时返回 false */
export function hasPerm(perm: string): boolean {
  return currentRole.permissions.includes(perm);
}

export function subscribeRole(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

/** 当前用户角色（hook） */
export function useCurrentRole(): Role {
  return useSyncExternalStore(subscribeRole, getCurrentRole);
}

/** 全部角色（hook） */
export function useRoles(): Role[] {
  return useSyncExternalStore(subscribeRole, getRoles);
}

/** 模块加载即拉后端（fire-and-forget） */
if (typeof window !== 'undefined') {
  void loadRolesFromBackend();
}
