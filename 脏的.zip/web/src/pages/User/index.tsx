import React, { memo, useState } from 'react';
import { Card, Button, Dialog, Form, Input, MessagePlugin, Tag } from 'tdesign-react';
import { BrowserRouterProps } from 'react-router-dom';
import { currentUser, changePassword, LoginUser } from 'services/electionApi';
import styles from './index.module.less';

const { FormItem } = Form;

const roleMap: Record<string, string> = {
  platform_admin: '平台管理员',
  super_admin: '超级管理员',
  sub_admin: '村级管理员',
  operator: '经办/书记',
  editor: '经办编辑',
  reviewer: '审核员',
  candidate: '参选人',
};

export default memo((_props: BrowserRouterProps) => {
  const user = currentUser() as LoginUser | null;
  const userName = user?.name || user?.phone || '未登录用户';
  const userPhone = user?.phone || '--';
  const orgTypeLabel = user?.orgType === 'community' ? '社区' : user?.orgType === 'village' ? '村' : '';
  const userOrg = user?.orgName || user?.orgId || '--';
  const userRole = (user?.role && roleMap[user.role]) || user?.role || '--';
  const [pwdChanged, setPwdChanged] = useState(() => localStorage.getItem('cxq_pwd_changed') === '1');

  // 改密码弹窗
  const [open, setOpen] = useState(false);
  const [oldPwd, setOldPwd] = useState('');
  const [newPwd, setNewPwd] = useState('');
  const [confirmPwd, setConfirmPwd] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async () => {
    if (!oldPwd) return setErr('请输入当前密码');
    if (newPwd.length < 6) return setErr('新密码至少 6 位');
    if (newPwd !== confirmPwd) return setErr('两次输入的新密码不一致');
    setBusy(true); setErr('');
    try {
      await changePassword(oldPwd, newPwd);
      MessagePlugin.success('密码修改成功，下次登录请使用新密码');
      localStorage.setItem('cxq_pwd_changed', '1');
      setPwdChanged(true);
      setOpen(false); setOldPwd(''); setNewPwd(''); setConfirmPwd('');
    } catch (e: any) {
      const msg = e?.response?.data?.error;
      setErr(msg === 'invalid_old_password' ? '当前密码不正确' : (msg || '修改失败，请重试'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <Card className={styles.welcome} bordered={false}>
        <div className={styles.name}>您好，{userName}</div>
        <div className={styles.regular}>欢迎使用村居换届系统统一后台</div>
      </Card>

      <Card className={styles.userinfo} title='个人信息' bordered={false} header>
        <div className={styles.row}>
          <div className={styles.cell}>
            <div className={styles.label}>手机号</div>
            <div className={styles.value}>{userPhone}</div>
          </div>
          <div className={styles.cell}>
            <div className={styles.label}>归属地</div>
            <div className={styles.value}>{userOrg}{orgTypeLabel ? <Tag theme='default' variant='light' style={{ marginLeft: 6 }}>{orgTypeLabel}</Tag> : null}</div>
          </div>
          <div className={styles.cell}>
            <div className={styles.label}>角色</div>
            <div className={styles.value}><Tag theme='primary' variant='light'>{userRole}</Tag></div>
          </div>
          <div className={styles.cell}>
            <div className={styles.label}>初始密码</div>
            <div className={styles.value}>
              {pwdChanged ? <Tag theme='success' variant='light'>已修改</Tag> : (
                <>
                  <code>123456</code>
                  <Button size='small' variant='text' onClick={() => setOpen(true)}>改密码</Button>
                </>
              )}
            </div>
          </div>
        </div>
      </Card>

      <Dialog header='修改密码' visible={open} onClose={() => setOpen(false)}
        footer={
          <>
            <Button variant='outline' onClick={() => setOpen(false)}>取消</Button>
            <Button theme='primary' loading={busy} onClick={submit}>确认修改</Button>
          </>
        }
      >
        <Form labelWidth={96}>
          <FormItem label='当前密码'>
            <Input type='password' value={oldPwd} onChange={(v) => setOldPwd(v as string)} placeholder='请输入当前密码' />
          </FormItem>
          <FormItem label='新密码'>
            <Input type='password' value={newPwd} onChange={(v) => setNewPwd(v as string)} placeholder='至少 6 位' />
          </FormItem>
          <FormItem label='确认新密码'>
            <Input type='password' value={confirmPwd} onChange={(v) => setConfirmPwd(v as string)} placeholder='再次输入新密码' />
          </FormItem>
          {err && <div className={styles.pwdErr}>{err}</div>}
        </Form>
      </Dialog>
    </div>
  );
});
