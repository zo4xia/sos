import { useEffect, useState } from 'react';
import { Button, Dialog, Form, Input, Select, Switch, Table, Tag, MessagePlugin } from 'tdesign-react';
import Page from 'layouts/components/Page';
import {
  getWebhookSubs,
  createWebhookSub,
  updateWebhookSub,
  deleteWebhookSub,
  testWebhookSub,
  type WebhookSub,
} from 'services/electionApi';
import Style from './index.module.less';

const { FormItem } = Form;
const CHANNEL_LABEL = { wecom: '企业微信', feishu: '飞书', plain: '普通推送' } as const;

export default function Notifications() {
  const [list, setList] = useState<WebhookSub[]>([]);
  const [loading, setLoading] = useState(false);
  const [createVisible, setCreateVisible] = useState(false);
  const [editing, setEditing] = useState<WebhookSub | null>(null);
  const [form] = Form.useForm();

  const load = async () => {
    setLoading(true);
    try {
      setList((await getWebhookSubs()) || []);
    } catch (e) {
      MessagePlugin.error((e as Error).message || '加载失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const openForm = (row?: WebhookSub) => {
    setEditing(row || null);
    setCreateVisible(true);
    if (row) {
      form.setFieldsValue({ name: row.name, channel: row.channel, url: row.url, mobile: row.mobile || '' });
    } else {
      form.reset();
      form.setFieldsValue({ channel: 'wecom' });
    }
  };

  const onSave = async () => {
    const ok = await form.validate();
    if (!ok) return;
    const v = form.getFieldsValue(true);
    try {
      if (editing) {
        await updateWebhookSub(editing.id, { name: v.name, url: v.url, mobile: v.mobile || null });
        MessagePlugin.success('订阅已更新');
      } else {
        await createWebhookSub({ name: v.name, channel: v.channel, url: v.url, mobile: v.mobile || undefined });
        MessagePlugin.success('订阅已新增');
      }
      setCreateVisible(false);
      void load();
    } catch (e) {
      MessagePlugin.error((e as Error).message || '保存失败');
    }
  };

  const onToggle = async (row: WebhookSub, active: boolean) => {
    try {
      await updateWebhookSub(row.id, { active });
      MessagePlugin.success(active ? '已启用' : '已停用');
      void load();
    } catch (e) {
      MessagePlugin.error((e as Error).message || '操作失败');
    }
  };

  const onTest = async (row: WebhookSub) => {
    try {
      const r = await testWebhookSub(row.id);
      if (r.ok) MessagePlugin.success(`测试消息已发送（${row.name}）`);
      else MessagePlugin.error(`webhook 返回异常（HTTP ${r.status}）`);
    } catch (e) {
      MessagePlugin.error('测试失败：webhook 不可达，请检查 URL');
    }
  };

  const onDelete = async (row: WebhookSub) => {
    try {
      await deleteWebhookSub(row.id);
      MessagePlugin.success(`已删除「${row.name}」`);
      void load();
    } catch (e) {
      MessagePlugin.error((e as Error).message || '删除失败');
    }
  };

  const columns = [
    { colKey: 'name', title: '名称/人员', width: 140 },
    {
      colKey: 'channel',
      title: '渠道',
      width: 110,
      cell: ({ row }: { row: WebhookSub }) => (
        <Tag theme={row.channel === 'wecom' ? 'success' : 'primary'} variant='light'>
          {CHANNEL_LABEL[row.channel]}
        </Tag>
      ),
    },
    {
      colKey: 'url',
      title: 'Webhook URL',
      minWidth: 220,
      cell: ({ row }: { row: WebhookSub }) => <div className={Style.urlText}>{row.url}</div>,
    },
    {
      colKey: 'mobile',
      title: '手机号(@用)',
      width: 140,
      cell: ({ row }: { row: WebhookSub }) => row.mobile || <span style={{ color: '#999' }}>—</span>,
    },
    {
      colKey: 'active',
      title: '状态',
      width: 90,
      cell: ({ row }: { row: WebhookSub }) => (
        <Switch value={row.active} onChange={(v) => void onToggle(row, !!v)} />
      ),
    },
    {
      colKey: 'op',
      title: '操作',
      width: 200,
      cell: ({ row }: { row: WebhookSub }) => (
        <div className={Style.tagWrap}>
          <Button variant='text' theme='primary' size='small' onClick={() => void onTest(row)}>
            测试
          </Button>
          <Button variant='text' size='small' onClick={() => openForm(row)}>
            编辑
          </Button>
          <Button variant='text' theme='danger' size='small' onClick={() => void onDelete(row)}>
            删除
          </Button>
        </div>
      ),
    },
  ];

  return (
    <Page breadcrumbs={['后台管理', '通知配置']}>
      <div className={Style.wrap}>
        <div className={Style.pageHead}>
          <div>
            <h2 className={Style.pageTitle}>通知配置</h2>
            <div className={Style.sub}>
              <span>webhook 机器人通知 · 动作触发时推送群消息</span>
              <span className={Style.hint}>（企业微信 / 飞书群机器人）</span>
            </div>
          </div>
          <div className={Style.tagWrap}>
            <Button
              variant='outline'
              onClick={() => MessagePlugin.info('当前为演示模拟版本，短信通道需开通')}
            >
              短信通知
            </Button>
            <Button theme='primary' onClick={() => openForm()}>
              ＋ 新增订阅
            </Button>
          </div>
        </div>

        <div className={Style.tableBox}>
          <Table rowKey='id' columns={columns} data={list} loading={loading} />
        </div>

        <div className={Style.ruleBox}>
          <b>通知说明：</b>
          <span>
            三种渠道：<b>普通推送</b>（Bark 等，URL 后直接追加内容）、<b>企业微信</b> / <b>飞书</b>（群机器人）。
            多个接收人点「＋新增订阅」逐个添加；手机号仅企业微信渠道用于 @ 提醒。触发点：提案审批、公告发布、材料/候选人审核结果、阶段节点提醒。
          </span>
        </div>
      </div>

      {/* 新增/编辑订阅弹窗 */}
      <Dialog
        header={editing ? `编辑订阅：${editing.name}` : '新增 webhook 订阅'}
        visible={createVisible}
        width={520}
        onClose={() => setCreateVisible(false)}
        footer={
          <>
            <Button variant='text' onClick={() => setCreateVisible(false)}>
              取消
            </Button>
            <Button theme='primary' onClick={() => void onSave()}>
              保存
            </Button>
          </>
        }
      >
        <Form form={form} labelWidth={110}>
          <FormItem name='name' label='名称/人员' rules={[{ required: true, message: '请填写名称（如：张三）' }]}>
            <Input placeholder='如：张三 / 换届工作群' />
          </FormItem>
          <FormItem name='channel' label='渠道' rules={[{ required: true, message: '请选择渠道' }]}>
            <Select
              options={[
                { label: '普通推送（Bark 等，URL+内容）', value: 'plain' },
                { label: '企业微信（群机器人）', value: 'wecom' },
                { label: '飞书（群机器人）', value: 'feishu' },
              ]}
            />
          </FormItem>
          <FormItem name='url' label='推送地址' rules={[{ required: true, message: '请填写推送地址' }]}>
            <Input placeholder='Bark: https://api.day.app/你的key/  ｜ 企微/飞书: 机器人 webhook URL' />
          </FormItem>
          <FormItem name='mobile' label='手机号(选填)' extra='企业微信渠道填了会自动 @ 提醒本人'>
            <Input placeholder='如：13800000000' />
          </FormItem>
        </Form>
      </Dialog>
    </Page>
  );
}
