import { Table, Tag } from 'tdesign-react';
import Page from 'layouts/components/Page';
import { useRoles, useCurrentRole } from 'utils/roleStore';
import Style from './index.module.less';

/** 权限点「资源:动作」→ 中文标签（只读展示用） */
const RESOURCE_LABEL: Record<string, string> = {
  proposal: '提案',
  material: '材料',
  candidate: '候选人',
  announcement: '公告',
  account: '账号',
  org: '组织',
  role: '角色',
  position: '岗位',
  data: '数据',
};
const ACT_LABEL: Record<string, string> = {
  create: '新增',
  edit: '编辑',
  review: '审核',
  publish: '发布',
  manage: '管理',
  view: '查看',
};
function permLabel(perm: string) {
  const [res, act] = perm.split(':');
  return `${RESOURCE_LABEL[res] || res}·${ACT_LABEL[act] || act}`;
}

export default function Roles() {
  const roles = useRoles();
  const current = useCurrentRole();

  const columns = [
    { colKey: 'name', title: '角色名称', width: 130 },
    {
      colKey: 'key',
      title: '角色编码',
      width: 170,
      cell: ({ row }: { row: { key: string } }) => (
        <span style={{ fontFamily: 'Consolas,monospace', fontSize: 12 }}>{row.key}</span>
      ),
    },
    {
      colKey: 'is_staff',
      title: '类型',
      width: 90,
      cell: ({ row }: { row: { is_staff: boolean } }) =>
        row.is_staff ? (
          <Tag theme='primary' variant='light'>
            后台
          </Tag>
        ) : (
          <Tag theme='default' variant='light'>
            小程序
          </Tag>
        ),
    },
    {
      colKey: 'permissions',
      title: '权限点',
      minWidth: 320,
      cell: ({ row }: { row: { permissions: string[]; is_system: boolean } }) => (
        <div className={Style.permTags}>
          {row.permissions.length ? (
            row.permissions.map((p) => (
              <Tag key={p} theme={row.is_system ? 'primary' : 'warning'} variant='outline'>
                {permLabel(p)}
              </Tag>
            ))
          ) : (
            <span style={{ color: '#6B7280', fontSize: 12 }}>仅查看</span>
          )}
        </div>
      ),
    },
  ];

  return (
    <Page breadcrumbs={['后台管理', '角色管理']}>
      <div className={Style.wrap}>
        <div className={Style.pageHead}>
          <div>
            <h2 className={Style.pageTitle}>角色管理</h2>
            <div className={Style.sub}>
              当前登录角色：
              <Tag theme='primary' variant='light'>
                {current.name}
              </Tag>
              <span className={Style.hint}>（角色跟随登录，权限由后端 roles / role_permissions 表控制）</span>
            </div>
          </div>
        </div>

        <div className={Style.tableBox}>
          <Table rowKey='key' columns={columns} data={roles} />
        </div>

        {/* 鉴权规则说明 */}
        <div className={Style.ruleBox}>
          <b>鉴权规则：</b>
          <span>
            页面不做细粒度按钮鉴权；关键操作（审核 / 发布 / 审批 / 建账号）由后端静默验证角色权限，无权限时报错。
          </span>
        </div>
      </div>
    </Page>
  );
}
