import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Button,
  Form,
  type FormInstanceFunctions,
  Input,
  MessagePlugin,
  Select,
  type SubmitContext,
} from 'tdesign-react';
import { BrowseIcon, BrowseOffIcon, LockOnIcon, UserIcon } from 'tdesign-icons-react';
import classnames from 'classnames';
import { apiLogin, apiOrgs, saveLogin, type Org } from 'services/electionApi';
import { syncAll } from 'utils/liveSync';

import Style from './index.module.less';

const { FormItem } = Form;

/**
 * 登录（v6.1：真调后端 POST /api/login，JWT 存 cxq_token）
 * 演示账号已预填：13800000001 / 123456 / 平台管理（张主任·platform_admin）
 */
export default function Login() {
  const [showPsw, toggleShowPsw] = useState(false);
  // group 为按街道/镇分组展示用（TDesign Select 分组选项），真实列表与兜底数组都会带该字段
  const [orgs, setOrgs] = useState<Array<{ label: string; value: string; group?: string }>>([]);
  const [submitting, setSubmitting] = useState(false);
  const formRef = useRef<FormInstanceFunctions>();
  const navigate = useNavigate();

  // 拉真实组织列表（按后端返回展示真实组织，剔除 boss 假选项）
  useEffect(() => {
    let alive = true;
    apiOrgs()
      .then((list: Org[]) => {
        if (!alive || !list?.length) return;
        const opts: Array<{ label: string; value: string; group: string }> = list
          .filter((o) => o.orgId !== 'boss' && o.type !== 'platform')
          .map((o) => ({ label: o.name, value: o.orgId, group: o.orgType === 'community' ? '🏘 社区（居委会）' : '🏡 村（村委会）' }));
        setOrgs(opts);
        // 默认选中「村」组织（演示账号均在村），避免误选社区导致 401
        const first = opts.find((o) => o.group?.includes('村')) || opts[0];
        if (first && formRef.current) {
          formRef.current.setFieldsValue({ orgId: first.value });
        }
      })
      .catch(() => {
        if (alive) setOrgs([]);
      });
    return () => { alive = false; };
  }, []);

  const onSubmit = async (e: SubmitContext) => {
    if (e.validateResult !== true) return;
    const formValue = formRef.current?.getFieldsValue?.(true) || {};
    const { orgId, phone, password } = formValue;
    if (!orgId || !phone || !password) {
      MessagePlugin.error('请完整填写归属地、手机号和密码');
      return;
    }
    setSubmitting(true);
    try {
      const { token, user } = await apiLogin(String(phone), String(password), String(orgId));
      saveLogin(token, user);
      MessagePlugin.success(`欢迎，${user.name || user.phone} · ${user.orgName || user.orgId}`);
      syncAll(); // 后台拉真实数据灌入各 store（不阻塞跳转）
      navigate('/election/home');
    } catch (err) {
      const e2 = err as Error;
      MessagePlugin.error(e2.message?.includes('归属地') ? e2.message : `登录失败：${e2.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <Form ref={formRef} className={classnames(Style.itemContainer)} labelWidth={0} onSubmit={onSubmit}>
        {/* ① 归属地（真实 123 组织） */}
        <FormItem
          name='orgId'
          initialData={orgs[0]?.value}
          rules={[{ required: true, message: '请选择归属地', type: 'error' }]}
        >
          <Select size='large' placeholder='请选择归属地（村/社区）' options={orgs} filterable />
        </FormItem>

        {/* ② 手机号（演示账号预填） */}
        <FormItem
          name='phone'
          initialData='13800000001'
          rules={[{ required: true, message: '手机号必填', type: 'error' }]}
        >
          <Input size='large' maxlength={11} placeholder='请输入手机号（管理员 13800000001）' prefixIcon={<UserIcon />} />
        </FormItem>

        {/* ③ 密码 */}
        <FormItem name='password' initialData='123456' rules={[{ required: true, message: '密码必填', type: 'error' }]}>
          <Input
            size='large'
            type={showPsw ? 'text' : 'password'}
            clearable
            placeholder='请输入登录密码（演示 123456）'
            prefixIcon={<LockOnIcon />}
            suffixIcon={
              showPsw ? (
                <BrowseIcon onClick={() => toggleShowPsw((current) => !current)} />
              ) : (
                <BrowseOffIcon onClick={() => toggleShowPsw((current) => !current)} />
              )
            }
          />
        </FormItem>

        <FormItem className={Style.btnContainer}>
          <Button block size='large' type='submit' loading={submitting}>
            登录
          </Button>
        </FormItem>
      </Form>
    </div>
  );
}
