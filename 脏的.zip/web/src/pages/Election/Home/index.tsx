import React, { useEffect, useState } from 'react';
import { Card, Tag, Progress, Alert, Loading, Empty } from 'tdesign-react';
import { CalendarIcon, TimeIcon, NotificationIcon } from 'tdesign-icons-react';
import {
  currentUser, getElections, getStages, getAnnouncements,
  daysBetween, todayStr,
  type Election, type Stage, type Announcement,
} from 'services/electionApi';
import Style from './index.module.less';

interface LiveState {
  org: string;
  term: string;
  dDate: string;
  daysToD: number;
  progress: number;
  currentStage?: Stage;
  nextStage?: Stage;
  announcements: Announcement[];
}

const fmt = (date?: string) => (date ? String(date).slice(0, 10) : '—');

export default function Home() {
  const [state, setState] = useState<LiveState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      const user = currentUser();
      if (!user) {
        setError('请先使用真实演示账号登录。工作台不会展示 Mock 数据。');
        setLoading(false);
        return;
      }
      try {
        const elections: Election[] = await getElections();
        if (!alive) return;
        if (!elections.length) {
          setError('当前组织还没有换届封地，请先在后台创建真实换届数据。');
          return;
        }
        const election = elections.find((item) => item.elStatus === 'in_progress') || elections[0];
        const [stages, announcements] = await Promise.all([
          getStages(election.electionId),
          getAnnouncements(),
        ]);
        if (!alive) return;
        const completed = stages.filter((stage) => stage.stageStatus === '已完成').length;
        const currentStage = stages.find((stage) => stage.stageStatus === '进行中');
        const nextStage = stages.find((stage) => stage.stageStatus === '未开始');
        const dDate = fmt(election.elElectionDate);
        setState({
          org: election.orgName || election.orgId,
          term: election.elTerm,
          dDate,
          daysToD: dDate === '—' ? 0 : daysBetween(dDate, todayStr()),
          progress: stages.length ? Math.round((completed / stages.length) * 100) : 0,
          currentStage,
          nextStage,
          announcements: announcements.filter((item) => item.annStatus === 'published').slice(0, 5),
        });
      } catch (cause) {
        if (alive) setError(cause instanceof Error ? cause.message : '真实数据加载失败');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  if (loading) return <Loading loading text='正在加载真实换届数据…' fullscreen={false} />;

  return (
    <div className={Style.page}>
      {error && <Alert theme='warning' message={error} close={false} style={{ marginBottom: 16 }} />}
      {!state ? (
        <Card title='村居换届工作台'><Empty description='暂无可展示的真实业务数据' /></Card>
      ) : (
        <>
          <Alert theme='success' message='当前页面仅展示 backend-new + 本地 PostgreSQL 的真实数据' close={false} style={{ marginBottom: 16 }} />
          <Card className={Style.heroCard} bordered={false}>
            <div className={Style.heroHead}>
              <div>
                <div className={Style.heroOrg}>{state.org} · {state.term}换届选举</div>
                <div className={Style.heroTitle}>依法选举 公正公开</div>
              </div>
              <Tag theme='primary' variant='light'>真实数据</Tag>
            </div>
            <div className={Style.heroStats}>
              <div className={Style.heroStat}><div className={Style.heroNum}>{state.daysToD}</div><div className={Style.heroLbl}>距 D 日（天）</div></div>
              <div className={Style.heroStat}><div className={Style.heroNum}>{state.dDate}</div><div className={Style.heroLbl}>正式选举日</div></div>
              <div className={Style.heroStat}><div className={Style.heroNum}>{state.progress}%</div><div className={Style.heroLbl}>法定阶段进度</div></div>
            </div>
            <Progress percentage={state.progress} color='#0052d9' trackColor='#eef0f4' />
            <div className={Style.heroStage}>当前阶段：<b>{state.currentStage?.stageName || '尚未进入执行阶段'}</b></div>
          </Card>

          <div className={Style.grid}>
            <Card title={<div className={Style.cardTitle}><NotificationIcon /> 已发布公告</div>} className={Style.colMain}>
              {state.announcements.length ? (
                <div className={Style.annList}>{state.announcements.map((item) => (
                  <div key={item.id} className={Style.annRow}>
                    <Tag theme='default' variant='outline' size='small'>公告</Tag>
                    <span className={Style.annTitle}>{item.annCode || '未编号'} · {item.annTitle}</span>
                    <span className={Style.annDate}>{fmt(item.annPublishTime)}</span>
                  </div>
                ))}</div>
              ) : <Empty description='暂无已发布公告' />}
            </Card>
            <Card title={<div className={Style.cardTitle}><CalendarIcon /> 下一法定阶段</div>} className={Style.colSide}>
              {state.nextStage ? (
                <><div className={Style.fcName}>{state.nextStage.stageName}</div><div className={Style.fcLine}><TimeIcon /> {fmt(state.nextStage.stageStartDate)} ~ {fmt(state.nextStage.stageEndDate)}</div></>
              ) : <Empty description='暂无后续阶段' />}
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
