import { useEffect, useMemo, useState } from 'react';
import { Button, Table, Tag, MessagePlugin } from 'tdesign-react';
import Page from 'layouts/components/Page';
import {
  getAnnouncements,
  getElections,
  getStages,
  type Announcement,
  type Election,
  type Stage,
} from 'services/electionApi';
import Style from './index.module.less';

type ElectionRow = Election & { stages: Stage[] };

const statusMeta: Record<string, { label: string; theme: 'success' | 'warning' | 'default' }> = {
  published: { label: '已发布', theme: 'success' },
  draft: { label: '待发布', theme: 'warning' },
};

export default function Announcements() {
  const [elections, setElections] = useState<ElectionRow[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [current, setCurrent] = useState<ElectionRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    Promise.all([getElections(), getAnnouncements()])
      .then(async ([es, anns]) => {
        const rows = await Promise.all(es.map(async (e) => ({ ...e, stages: await getStages(e.electionId).catch(() => []) })));
        if (active) { setElections(rows); setAnnouncements(anns); }
      })
      .catch((e: Error) => { if (active) setError(e.message || '真实数据加载失败'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const currentAnnouncements = useMemo(
    () => announcements.filter((item) => item.elId === current?.elId),
    [announcements, current],
  );

  if (!current) {
    return (
      <Page breadcrumbs={['选举管理', '公告通知', '公告']}>
        <div className={Style.wrap}>
          <div className={Style.pageHead}><div><h2 className={Style.pageTitle}>公告列表</h2><div className={Style.sub}>数据来自 backend-new 实时接口，先选择一届查看阶段与公告。</div></div></div>
          {error && <div className={Style.error}>{error}</div>}
          <Table
            rowKey='electionId'
            loading={loading}
            data={elections}
            columns={[
              { colKey: 'elTerm', title: '届次', width: 120 },
              { colKey: 'elName', title: '选举活动', minWidth: 240 },
              { colKey: 'elElectionDate', title: '正式选举日', width: 140 },
              { colKey: 'stageCount', title: '阶段', width: 90, cell: ({ row }: { row: ElectionRow }) => row.stages.length },
              { colKey: 'announcementCount', title: '公告', width: 90, cell: ({ row }: { row: ElectionRow }) => announcements.filter((a) => a.elId === row.elId).length },
              { colKey: 'op', title: '操作', width: 120, cell: ({ row }: { row: ElectionRow }) => <Button variant='text' theme='primary' onClick={() => setCurrent(row)}>查看列表</Button> },
            ]}
            empty='暂无 backend-new 选举活动'
          />
        </div>
      </Page>
    );
  }

  return (
    <Page breadcrumbs={['选举管理', '公告通知', current.elTerm || current.elName]}>
      <div className={Style.wrap}>
        <div className={Style.pageHead}>
          <div><Button variant='text' onClick={() => setCurrent(null)}>← 返回届次列表</Button><h2 className={Style.pageTitle}>{current.elName} · 阶段/公告</h2><div className={Style.sub}>阶段来自 GET /api/elections/:electionId/stages，公告来自 GET /api/announcements。</div></div>
        </div>
        <Table rowKey='id' loading={loading} data={currentAnnouncements} columns={[
          { colKey: 'annCode', title: '公告编号', width: 110 },
          { colKey: 'annTitle', title: '公告标题', minWidth: 240 },
          { colKey: 'annStageKey', title: '所属阶段', width: 130, cell: ({ row }) => <Tag variant='light'>{current.stages.find((s) => s.stageKey === row.annStageKey)?.stageName || row.annStageKey || '未关联'}</Tag> },
          { colKey: 'annStatus', title: '状态', width: 100, cell: ({ row }) => { const m = statusMeta[row.annStatus] || { label: row.annStatus || '未知', theme: 'default' as const }; return <Tag theme={m.theme} variant='light'>{m.label}</Tag>; } },
          { colKey: 'annPublishTime', title: '发布时间', width: 180 },
          { colKey: 'annFiles', title: '附件', width: 80, cell: ({ row }) => row.annFiles?.length || 0 },
        ]} empty='该届暂无真实公告记录' />
      </div>
    </Page>
  );
}
