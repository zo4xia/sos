import { useMemo, useState, useEffect, useCallback } from 'react';
import { Table, Tag, Button, Dialog, Steps, Select, Input, Space, Descriptions, Textarea, Form, MessagePlugin } from 'tdesign-react';

const { FormItem } = Form;
import type { PrimaryTableCol } from 'tdesign-react';
import Page from 'layouts/components/Page';
import ElectionSessionList from 'components/ElectionSessionList';
import SessionDetailBar from 'components/ElectionSessionList/SessionDetailBar';
import { ElectionActivity, sessionNo } from 'utils/electionStore';
import { getCandidates, putCandidateRound, Candidate, CandidateMaterial, MaterialFile, apiFileUrl } from 'services/electionApi';
import { activityIdMap, isLiveSynced, syncAll } from 'utils/liveSync';
import Style from './index.module.less';

/**
 * 候选人管理（内部后台）· v6.2 人工录入版
 * ------------------------------------------------------------
 * 业务（甲方拍板，砍掉计算逻辑）：
 *   · 材料通过自动入池（R1 待审）
 *   · R1~R4 结果由甲方在系统手动点「通过/不通过」，可填理由（可选）
 *     ——评审方式：系统一键把材料链接打包发评审领导邮箱，线下评审，
 *       结果反馈后由经办在此录入。
 *   · 状态由轮次结果自动派生（待初审→待第2轮→…→正式候选人/落选）
 * 归属地隔离：登录后只读本归属地。
 * ------------------------------------------------------------
 */

const { StepItem } = Steps;

const ROUND_META: Record<string, { theme: 'success' | 'danger' | 'warning' | 'default'; label: string }> = {
  通过: { theme: 'success', label: '通过' },
  不通过: { theme: 'danger', label: '不通过' },
  待审: { theme: 'warning', label: '待审' },
};
const STATUS_THEME: Record<string, 'success' | 'warning' | 'danger' | 'default'> = {
  当选: 'success',
  正式候选人: 'success',
  待初审: 'warning',
  待第2轮: 'warning',
  待第3轮: 'warning',
  待第4轮考察: 'warning',
  初审退出: 'default',
  预选未入围: 'default',
  联审不通过: 'danger',
  考察不通过: 'danger',
  落选: 'danger',
};
const SOURCE_META = { self: '自荐', org_recommend: '组织推荐' } as const;

// 附件辅助（与材料页一致）：图片判定 / 去时间戳前缀 / 强制下载
const isImgFile = (name: string) => /\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(name || '');
const prettyFileName = (name: string) => {
  const m = (name || '').match(/^\d{10,}-[a-z0-9]+(\..+)$/i);
  return m ? m[1] : name;
};
const downloadFile = (url: string, name: string) => {
  const a = document.createElement('a');
  a.href = url;
  a.download = prettyFileName(name);
  a.target = '_blank';
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
};

interface IRound {
  result: '' | '通过' | '不通过' | '待审';
  reviewer?: string;
  time?: string;
  comment?: string;
}
interface ICandidate {
  id: string;
  activityId: number;
  name: string;
  gender: string;
  age: number;
  source: keyof typeof SOURCE_META;
  position: string;
  phone: string;
  rounds: [IRound, IRound, IRound, IRound];
  status: string;
  votes?: number;
  materials?: CandidateMaterial[]; // 后端内嵌：该候选人的全部报名材料与附件
}

const ROUND_NAMES = ['R1 初步提名·镇级初审', 'R2 竞选预选', 'R3 区级部门联审', 'R4 党委考察'];
const ROUND_SHORT = ['R1初审', 'R2预选', 'R3联审', 'R4考察'];

function mapRound(r: string | undefined, reviewer?: string, time?: string, comment?: string): IRound {
  return { result: (r || '') as IRound['result'], reviewer, time: (time || '').replace('T', ' ').slice(0, 16), comment };
}

/** 单个轮次小标签 */
function RoundTag({ r }: { r: IRound }) {
  if (!r.result) return <span className={Style.roundEmpty}>—</span>;
  return (
    <Tag size='small' theme={(ROUND_META[r.result] || { theme: 'default' }).theme} variant='light'>
      {(ROUND_META[r.result] || { label: r.result }).label}
    </Tag>
  );
}

export default function Candidates() {
  const [current, setCurrent] = useState<ElectionActivity | null>(null);
  const [list, setList] = useState<ICandidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [keyword, setKeyword] = useState('');
  const [detail, setDetail] = useState<ICandidate | null>(null);
  const [busy, setBusy] = useState(false);

  // 一键送审邮件已禁用：后端无 SMTP 接口
  // const [mailOpen, setMailOpen] = useState(false);
  // const [mailRound, setMailRound] = useState(1);
  // const [mailEmails, setMailEmails] = useState(() => localStorage.getItem('cxq_review_emails') || '');
  // const [mailNote, setMailNote] = useState('');
  // const [mailResult, setMailResult] = useState(null);
  // const [mailBusy, setMailBusy] = useState(false);

  // sendMail 已禁用：后端无 SMTP 接口

  const refresh = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    try {
      const rows = await getCandidates();
      setList((rows || []).map((c: Candidate) => ({
        id: c.id,
        activityId: activityIdMap.get(c.elId) || 90,
        name: c.candName,
        gender: c.candGender || '—',
        age: Number(c.candAge) || 0,
        source: (c.candSource === 'org_recommend' ? 'org_recommend' : 'self') as keyof typeof SOURCE_META,
        position: c.candPositionId || '委员',
        phone: c.candPhone || '',
        rounds: [
          mapRound(c.candR1, c.candR1Reviewer, c.candR1Time, c.candR1Comment),
          mapRound(c.candR2, c.candR2Reviewer, c.candR2Time, c.candR2Comment),
          mapRound(c.candR3, c.candR3Reviewer, c.candR3Time, c.candR3Comment),
          mapRound(c.candR4, c.candR4Reviewer, c.candR4Time, c.candR4Comment),
        ] as [IRound, IRound, IRound, IRound],
        status: c.candStatus || '待初审',
        // votes 已删除：甲方 A-002 禁止投票概念
        // 后端 /api/candidates 内嵌原始 materials（含 files[file_name,storage_key]），此处拼可访问 url
        materials: (c.materials || []).map((m: any) => ({
          id: m.id,
          matType: m.title || '',
          matStatus: m.status || '',
          matSubmitTime: m.submittedAt,
          matReviewComment: m.reviewNote || '',
          matFiles: (m.files || []).map((f: any) => ({ name: f.file_name, url: f.storage_key ? apiFileUrl(f.storage_key) : '' })),
        })) as CandidateMaterial[],
      })));
    } catch (e) {
      setLoadError(true);
      MessagePlugin.warning('候选人列表加载失败，请刷新重试');
    } finally { setLoading(false); }
  }, []);
  useEffect(() => {
    (async () => {
      if (!isLiveSynced()) await syncAll(); // 直达路由时补建映射
      await refresh();
    })();
  }, [refresh]);

  // 该候选人名下全部附件：直接取后端 /api/candidates 内嵌的 materials，跨多条材料记录扁平化（免二次请求）
  const candAllFiles: MaterialFile[] = (detail?.materials || []).flatMap((m) => (m.matFiles || []).map((f) => ({ ...f })));

  /** 外部送审：一键打开邮箱客户端，预填候选人信息+附件链接（政务线下送审用） */
  const externalReview = (cand: ICandidate) => {
    const subject = encodeURIComponent(`【候选人送审】${cand.name} - ${cand.position}`);
    const fileList = candAllFiles.map((f, i) => `${i + 1}. ${f.name}: ${f.url}`).join('\n');
    const body = encodeURIComponent(
      `候选人信息：\n姓名：${cand.name}\n性别/年龄：${cand.gender} / ${cand.age}\n手机号：${cand.phone}\n竞选岗位：${cand.position}\n来源：${SOURCE_META[cand.source]}\n当前状态：${cand.status}\n\n报名材料附件（共${candAllFiles.length}个，点击链接预览/下载）：\n${fileList}\n\n请审核后将结果反馈给经办人，由经办人在系统内录入审核结论。`
    );
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  /** 下载候选人信息（生成文本文件，政务存档用） */
  const downloadCandidateInfo = (cand: ICandidate) => {
    const fileList = candAllFiles.map((f, i) => `  ${i + 1}. ${f.name} (${f.url})`).join('\n');
    const roundsText = cand.rounds.map((r, i) => `  ${ROUND_NAMES[i]}：${r.result || '未到轮次'}${r.reviewer ? `（审核人：${r.reviewer}）` : ''}${r.time ? ` ${r.time}` : ''}${r.comment ? ` 意见：${r.comment}` : ''}`).join('\n');
    const content = `═══════════════════════════════\n  候选人信息存档表\n═══════════════════════════════\n\n姓名：${cand.name}\n性别/年龄：${cand.gender} / ${cand.age}\n手机号：${cand.phone}\n竞选岗位：${cand.position}\n来源：${SOURCE_META[cand.source]}\n当前状态：${cand.status}\n\n四轮审核记录：\n${roundsText}\n\n报名材料附件（共${candAllFiles.length}个）：\n${fileList}\n\n存档时间：${new Date().toLocaleString('zh-CN')}\n═══════════════════════════════`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `候选人信息_${cand.name}_${cand.position}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  /** 当前轮次审核截止日期（从stages取） */
  const roundDeadline = (roundIdx: number): string => {
    if (!current?.stages) return '';
    const keys = ['prelim_shortlist', 'nominate_cont', 'joint_review', 'campaign_prep'];
    const stage = current.stages.find(s => s.key === keys[roundIdx]);
    return stage?.endDate || '';
  };

  /** 录入某轮结果（可选理由），成功后刷新 */
  const putRound = async (cand: ICandidate, roundIdx: number, result: '通过' | '不通过', reason: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const roundKey = ('R' + (roundIdx + 1)) as 'R1' | 'R2' | 'R3' | 'R4';
      const decision = result === '通过' ? 'approved' : 'rejected';
      const r = await putCandidateRound(cand.id, roundKey, decision, reason.trim() || undefined);
      MessagePlugin.success(`${cand.name} · R${roundIdx + 1} 已录入「${result}」，状态：${r.status}`);
      await refresh();
      // 同步刷新详情弹窗
      const updated = list.length;
      if (detail && detail.id === cand.id) {
        const rows = await getCandidates();
        const nc = (rows || []).find((x: Candidate) => x.id === cand.id);
        if (nc) {
          setDetail({
            ...detail,
            rounds: [
              mapRound(nc.candR1, nc.candR1Reviewer, nc.candR1Time, nc.candR1Comment),
              mapRound(nc.candR2, nc.candR2Reviewer, nc.candR2Time, nc.candR2Comment),
              mapRound(nc.candR3, nc.candR3Reviewer, nc.candR3Time, nc.candR3Comment),
              mapRound(nc.candR4, nc.candR4Reviewer, nc.candR4Time, nc.candR4Comment),
            ] as [IRound, IRound, IRound, IRound],
            status: nc.candStatus || '待初审',
          });
        }
      }
      void updated;
    } catch (e) {
      MessagePlugin.error((e as Error).message || '录入失败');
    } finally { setBusy(false); }
  };

  const filtered = useMemo(
    () =>
      list.filter((c) => {
        if (current && c.activityId !== current.id) return false;
        if (statusFilter && c.status !== statusFilter) return false;
        if (sourceFilter && c.source !== sourceFilter) return false;
        if (keyword && !`${c.name}${c.phone}`.includes(keyword.trim())) return false;
        return true;
      }),
    [list, current, statusFilter, sourceFilter, keyword],
  );

  /** 当前可操作的轮（前置全通过的第一个空/待审轮）；全过=null */
  const activeRound = (c: ICandidate) => {
    for (let i = 0; i < 4; i += 1) {
      if (c.rounds[i].result !== '通过') return i;
    }
    return null;
  };

  // 从当前届 stages 提取四轮审核日期区间，表头显示（甲方要求：日期很重要）
  const roundHeaders = useMemo(() => {
    if (!current?.stages) return ['R1初审', 'R2预选', 'R3联审', 'R4考察'];
    const r1 = current.stages.find(s => s.key === 'prelim_shortlist');
    const r2 = current.stages.find(s => s.key === 'nominate_cont');
    const r3 = current.stages.find(s => s.key === 'joint_review');
    const r4 = current.stages.find(s => s.key === 'campaign_prep');
    return [
      r1 ? `R1初审（${r1.date}~${r1.endDate}）` : 'R1初审',
      r2 ? `R2预选（${r2.date}~${r2.endDate}）` : 'R2预选',
      r3 ? `R3联审（${r3.date}~${r3.endDate}）` : 'R3联审',
      r4 ? `R4考察（${r4.date}~${r4.endDate}）` : 'R4考察',
    ];
  }, [current]);

  const columns: PrimaryTableCol<ICandidate>[] = [
    { colKey: 'name', title: '姓名', width: 90, cell: ({ row }) => <b>{row.name}</b> },
    { colKey: 'info', title: '性别/年龄', width: 90, cell: ({ row }) => `${row.gender} · ${row.age}` },
    {
      colKey: 'source',
      title: '来源',
      width: 90,
      cell: ({ row }) => (
        <Tag size='small' variant='light' theme={row.source === 'org_recommend' ? 'default' : 'primary'}>
          {SOURCE_META[row.source]}
        </Tag>
      ),
    },
    { colKey: 'position', title: '岗位', width: 80 },
    { colKey: 'r1', title: roundHeaders[0], width: 150, cell: ({ row }) => <RoundTag r={row.rounds[0]} /> },
    { colKey: 'r2', title: roundHeaders[1], width: 150, cell: ({ row }) => <RoundTag r={row.rounds[1]} /> },
    { colKey: 'r3', title: roundHeaders[2], width: 150, cell: ({ row }) => <RoundTag r={row.rounds[2]} /> },
    { colKey: 'r4', title: roundHeaders[3], width: 150, cell: ({ row }) => <RoundTag r={row.rounds[3]} /> },
    {
      colKey: 'status',
      title: '当前状态',
      width: 110,
      cell: ({ row }) => (
        <Tag size='small' theme={STATUS_THEME[row.status] ?? 'warning'} variant='light'>
          {row.status}
        </Tag>
      ),
    },
    // 得票列已删除：甲方 A-002 禁止投票概念
    {
      colKey: 'op',
      title: '操作',
      width: 170,
      fixed: 'right',
      cell: ({ row }) => {
        const ar = activeRound(row);
        return (
          <Space size={4}>
            <Button size='small' variant='text' theme='primary' onClick={() => setDetail(row)}>
              审核详情
            </Button>
            {ar != null && (
              <Button size='small' variant='text' theme='warning' onClick={() => setDetail(row)}>
                录 R{ar + 1}
              </Button>
            )}
          </Space>
        );
      },
    },
  ];

  // 第一级：活动列表
  if (!current) {
    return (
      <ElectionSessionList
        breadcrumbs={['办理中', '候选人管理', '候选人']}
        title='候选人审核'
        sub='先选届：候选人四轮审核按选举活动（届）隔离，进入某一届后只看该届候选人。'
        statLabel='候选人数'
        enterText='查看候选人'
        statOf={(a) => list.filter((c) => c.activityId === a.id).length}
        onEnter={setCurrent}
      />
    );
  }

  // 第二级：该届候选人明细
  return (
    <Page breadcrumbs={['办理中', '候选人管理', sessionNo(current.name)]}>
      <SessionDetailBar activity={current} onBack={() => setCurrent(null)} />
      <div className={Style.toolbar}>
        <Space size={8}>
          <Select
            value={statusFilter}
            onChange={(v) => setStatusFilter(v as string)}
            placeholder='全部状态'
            clearable
            style={{ width: 140 }}
            options={['待初审', '待第2轮', '待第3轮', '待第4轮考察', '正式候选人', '当选', '落选', '初审退出', '预选未入围', '联审不通过', '考察不通过'].map((v) => ({
              label: v,
              value: v,
            }))}
          />
          <Select
            value={sourceFilter}
            onChange={(v) => setSourceFilter(v as string)}
            placeholder='全部来源'
            clearable
            style={{ width: 120 }}
            options={[
              { label: '自荐', value: 'self' },
              { label: '组织推荐', value: 'org_recommend' },
            ]}
          />
          <Input
            value={keyword}
            onChange={setKeyword}
            placeholder='搜索姓名 / 手机号'
            clearable
            style={{ width: 200 }}
          />
        </Space>
        <span className={Style.tip}>评审流程：一键发邮箱 → 领导线下评 → 结果在此手动录入（可填理由）</span>
        {/* 一键送审邮箱已禁用：后端无 SMTP */}
      </div>

      <Table
        rowKey='id'
        columns={columns}
        data={filtered}
        loading={loading}
        bordered
        stripe
        hover
        tableLayout='fixed'
        maxHeight='calc(100vh - 280px)'
        empty={loadError ? '候选人加载失败，请刷新重试' : filtered.length === 0 && list.length > 0 ? '没有符合当前筛选条件的候选人' : '暂无候选人（材料审核通过后自动进入）'}
      />

      {/* 一键送审邮件已禁用：后端无 SMTP */}

      {/* 四轮审核详情：每轮手动录通过/不通过 + 可选理由 */}
      <Dialog
        header={`候选人四轮审核 · ${detail?.name ?? ''}`}
        visible={!!detail}
        onClose={() => setDetail(null)}
        width={720}
        footer={
          <Button variant='outline' onClick={() => setDetail(null)}>
            关闭
          </Button>
        }
      >
        {detail && (
          <div className={Style.detail}>
            <Descriptions
              column={3}
              bordered
              size='small'
              items={[
                { label: '姓名', content: detail.name },
                { label: '岗位', content: detail.position },
                { label: '来源', content: SOURCE_META[detail.source] },
                { label: '性别/年龄', content: `${detail.gender} · ${detail.age}` },
                { label: '手机号', content: detail.phone },
                {
                  label: '当前状态',
                  content: (
                    <Tag size='small' theme={STATUS_THEME[detail.status] ?? 'warning'}>
                      {detail.status}
                    </Tag>
                  ),
                },
              ]}
            />
            {/* 操作栏：外部送审 + 下载候选人信息（政务线下存档用） */}
            <div style={{ display: 'flex', gap: 8, margin: '12px 0', flexWrap: 'wrap' }}>
              <Button size='small' theme='primary' variant='outline' onClick={() => externalReview(detail)}>
                ✉️ 外部送审（抄送邮箱）
              </Button>
              <Button size='small' theme='default' variant='outline' onClick={() => downloadCandidateInfo(detail)}>
                📄 下载候选人信息（存档）
              </Button>
              <span style={{ fontSize: 12, color: '#9aa3af', alignSelf: 'center' }}>
                外部送审打开邮箱预填信息；下载生成TXT存档文件
              </span>
            </div>
            <Steps current={(() => { const ar = activeRound(detail); return ar == null ? 4 : ar; })()} layout='vertical' theme='default'>
              {detail.rounds.map((r, i) => (
                <StepItem
                  key={i}
                  title={ROUND_NAMES[i]}
                  status={
                    r.result === '通过' ? 'finish' : r.result === '不通过' ? 'error' : r.result === '待审' ? 'process' : 'default'
                  }
                />
              ))}
            </Steps>

            {/* 每轮：结果标签 + 审核人/时间/理由 + 手动录入按钮 */}
            <div className={Style.roundList}>
              {detail.rounds.map((r, i) => {
                const ar = activeRound(detail);
                const canEdit = ar === i; // 只有当前待审轮可录
                return (
                  <div key={i} className={Style.roundLine}>
                    <span className={Style.roundName}>{ROUND_NAMES[i]}</span>
                    {r.result ? <RoundTag r={r} /> : <span className={Style.roundEmpty}>未到轮次</span>}
                    <span className={Style.roundMeta}>
                      {r.reviewer ? `${r.reviewer}${r.time ? ` · ${r.time}` : ''}` : ''}
                    </span>
                    {r.comment && <span className={Style.roundComment}>｜{r.comment}</span>}
                    {canEdit && (
                      <div>
                        {roundDeadline(i) && (
                          <div style={{ fontSize: 12, color: '#e67e22', marginBottom: 4, fontWeight: 600 }}>
                            ⏰ 审核截止日期：{roundDeadline(i)}（请在此日期前完成审核）
                          </div>
                        )}
                        <RoundInput cand={detail} roundIdx={i} busy={busy} onSubmit={(result, reason) => putRound(detail, i, result, reason)} />
                      </div>
                    )}
                    {!canEdit && ar != null && i > ar && (
                      <span className={Style.roundWait}>（待第 {i} 轮录入后开放）</span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* 报名材料附件（甲方 A-008：一人多附件，全部可预览/下载，支持整套下载） */}
            <div style={{ marginTop: 16 }}>
              <div style={{ fontWeight: 600, marginBottom: 8 }}>
                报名材料附件（共 {candAllFiles.length} 个 · 全部可预览 / 下载）
              </div>
              {candAllFiles.length > 0 ? (
                <>
                  <Button
                    size='small'
                    theme='primary'
                    variant='outline'
                    style={{ marginBottom: 8 }}
                    onClick={() => candAllFiles.forEach((f) => f.url && downloadFile(f.url, f.name))}
                  >
                    下载全部附件
                  </Button>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
                    {candAllFiles.map((f, i) => (
                      <div key={i} style={{ border: '1px solid #e7e7e7', borderRadius: 6, padding: 8, width: 150 }}>
                        {isImgFile(f.name) ? (
                          <img
                            src={f.url}
                            alt={f.name}
                            style={{ width: '100%', height: 96, objectFit: 'cover', cursor: 'pointer', borderRadius: 4 }}
                            onClick={() => f.url && window.open(f.url, '_blank')}
                          />
                        ) : (
                          <div style={{ height: 96, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32 }}>📄</div>
                        )}
                        <div style={{ fontSize: 12, marginTop: 4, wordBreak: 'break-all' }} title={f.name}>
                          {prettyFileName(f.name)}
                        </div>
                        <div style={{ marginTop: 4 }}>
                          <Button size='small' variant='text' theme='primary' onClick={() => f.url && window.open(f.url, '_blank')}>
                            预览
                          </Button>
                          <Button size='small' variant='text' onClick={() => downloadFile(f.url, f.name)}>
                            下载
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <span style={{ color: '#9aa3af' }}>暂无附件（材料审核通过后此处展示报名材料）</span>
              )}
            </div>

            {/* 得票显示已删除：甲方 A-002 禁止投票概念 */}
          </div>
        )}
      </Dialog>
    </Page>
  );
}

/** 单轮录入行：通过/不通过按钮 + 可选理由框 */
function RoundInput({ cand, roundIdx, busy, onSubmit }: {
  cand: ICandidate; roundIdx: number; busy: boolean;
  onSubmit: (result: '通过' | '不通过', reason: string) => void;
}) {
  const [reason, setReason] = useState('');
  void cand;
  return (
    <div className={Style.roundInputRow}>
      <Input
        value={reason}
        onChange={setReason}
        placeholder='理由（可选，如：预选得票未过线 / 材料补齐合格）'
        style={{ width: 300 }}
        maxlength={60}
      />
      <Button size='small' theme='success' variant='outline' disabled={busy} onClick={() => onSubmit('通过', reason)}>
        通过
      </Button>
      <Button size='small' theme='danger' variant='outline' disabled={busy} onClick={() => onSubmit('不通过', reason)}>
        不通过
      </Button>
      <span className={Style.roundHint}>评审结果来自邮箱送审反馈，手动录入</span>
      <div className={Style.roundTagShort}>{ROUND_SHORT[roundIdx]}</div>
    </div>
  );
}
