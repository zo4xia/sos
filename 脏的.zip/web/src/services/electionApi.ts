/**
 * electionApi.ts — 后端唯一调用层（v6.1 · Neon 云库版）
 *
 * 铁律：
 *  · 所有页面禁止直接 fetch/axios，一律走本文件
 *  · token 存 localStorage cxq_token / cxq_user，请求拦截器自动挂 JWT
 *  · 响应 code !== 0 → reject；401 → 清 token 跳登录
 *  · 写操作（发布/审核/得票）全部 PUT —— 后端 app.put 不响应 POST（实测坑）
 */
import axios from 'axios';
import type { AxiosResponse } from 'axios';

const http = axios.create({ baseURL: (import.meta as any).env?.VITE_API_BASE_URL || 'http://127.0.0.1:3100', timeout: 20000 });

http.interceptors.request.use((cfg) => {
  const token = localStorage.getItem('cxq_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

http.interceptors.response.use(
  (resp: AxiosResponse) => {
    const body = resp.data;
    if (body && typeof body.code === 'number' && body.code !== 0) {
      if (body.code === 401) {
        localStorage.removeItem('cxq_token');
        localStorage.removeItem('cxq_user');
        if (!location.pathname.includes('/login')) location.href = '/login';
      }
      return Promise.reject(new Error(body.message || `接口错误 ${body.code}`));
    }
    return body?.data !== undefined ? body.data : body;
  },
  (err) => {
    const status = err?.response?.status;
    if (status === 401) {
      localStorage.removeItem('cxq_token');
      localStorage.removeItem('cxq_user');
      if (!location.pathname.includes('/login')) location.href = '/login';
    }
    return Promise.reject(new Error(err?.response?.data?.message || err.message || '网络异常'));
  },
);

// ── 类型（后端返回 camelCase 别名）───────────────────────
export interface Org { orgId: string; name: string; town?: string; type?: string; status?: string; orgType?: 'village' | 'community' }
export interface Election { electionId: string; orgId: string; orgName?: string; orgType?: 'village' | 'community'; elId: string; elTerm: string; elName: string; elStatus: string; elElectionDate: string; elMethod?: string; elProposalId?: string; elNote?: string }
export interface Stage { stageKey: string; stageName: string; stageStatus: string; stageStartDate: string; stageEndDate: string; stageOrder: number; work?: string }
export interface Announcement { id: string; orgId: string; elId: string; annCode: string; annTitle: string; annStageKey: string; annStatus: string; annVersion?: number; annEditor?: string; annPublishTime?: string; annContent?: string;
  annSign?: string; annSignDate?: string; annOpenMaterialSubmit?: boolean; annPublishMode?: 'immediate' | 'scheduled'; annPublishAt?: string;
  annRemindHours?: number; annRemindTo?: string; annFiles?: MaterialFile[]; annPublicityDeadline?: string }
export interface Candidate extends _CandidateBase { }
interface _CandidateBase {
  id: string; orgId: string; elId: string; candName: string; candPositionId?: string; candSource?: string; candGender?: string; candAge?: number; candPhone?: string;
  candR1?: string; candR1Reviewer?: string; candR1Time?: string; candR1Comment?: string;
  candR2?: string; candR2Reviewer?: string; candR2Time?: string; candR2Comment?: string;
  candR3?: string; candR3Reviewer?: string; candR3Time?: string; candR3Comment?: string;
  candR4?: string; candR4Reviewer?: string; candR4Time?: string; candR4Comment?: string;
  candStatus?: string; candVotes?: number;
  materials?: CandidateMaterial[]; // 后端内嵌：该候选人的全部报名材料与附件（甲方 A-008）
}
export interface MaterialFile { name: string; url: string }
// /api/candidates 已按 mat_candidate_id 内嵌每位候选人的参选材料与附件，详情弹窗无需二次请求
export interface CandidateMaterial {
  id: string; matType?: string; matStatus?: string; matPositionId?: string;
  matSubmitTime?: string; matReviewComment?: string; matFiles?: MaterialFile[];
}
export interface Material {
  id: string; orgId: string; elId: string; matType?: string; matStatus: string; matPositionId?: string; matCandidateId?: string;
  matSubmitter?: string; matSubmitterPhone?: string; matSubmitTime?: string; matReviewTime?: string; matReviewer?: string; matReviewComment?: string;
  matStage?: string; matNote?: string; matFiles?: MaterialFile[];
}
/**
 * ── 字段批注 · 登录用户（LoginUser）──
 * 来源：POST /auth/admin/login（后端 login() 联查 4 表）
 *   orgId    ← organizations.id           归属地主键(uuid)
 *   orgName  ← organizations.name         归属地名称（演示村/演示社区）
 *   orgType  ← organizations.org_type     类型 village=村 / community=社区
 *   role     ← memberships.role           当前归属地下的角色
 *   name     ← users.display_name ?? phone 显示名（apiLogin 暂存 phone）
 *   id       ← users.id（apiLogin 暂为空串，未回填）
 * 本地持久化：localStorage.cxq_user（JSON），cxq_token 存 token
 */
export interface LoginUser { id: string; phone: string; orgId: string; orgName?: string; orgType?: string; name?: string; role: string; roles?: string; crossOrg?: boolean; roleKeys?: string[] }
export interface ReviewMailResult { round: number; receivers: string[]; count: number; mailed: boolean; sent: number; subject: string; text: string }
export interface ProposalPost { id?: string; position: string; count: number; requirement?: string | null }
export interface ProposalFile { id: string; fileName: string; mimeType?: string; sizeBytes?: number; storageKey: string; createdAt?: string }
export interface Proposal {
  id: string; organization_id: string; term_id?: string; unit_id?: string; organization_name?: string;
  name: string; d_day: string; org_type: 'village' | 'community';
  positions: { name: string; quota: number; requirement?: string }[];
  status: string; proposed_by?: string; reviewed_by?: string; created_at: string;
  files?: ProposalFile[]; // 后端 proposal_files 强外键附件表聚合
}
export interface Position { id: string; orgId: string; elId: string; posType: string; posQuota: number; posStatus: string; posDesc?: string }

export interface ApiError { code?: number; message?: string }

// ── 认证 ───────────────────────────────────────────────
export const apiLogin = async (phone: string, password: string, orgId: string) => {
  const user = await http.post('/auth/admin/login', { phone, password, organizationId: orgId }) as { token: string; organizationId: string; role: string; orgName?: string; orgType?: string; displayName?: string };
  return { token: user.token, user: { id: '', phone, orgId: user.organizationId, role: user.role, name: user.displayName || phone, orgName: user.orgName, orgType: user.orgType } as LoginUser };
};

/** ── 附件上传/预览 ──
 * 来源：POST /files/upload（后端统一入口，auth）；GET /files/:key（匿名，key=32hex 不可猜）
 * 材料/提案/公告共用；返回 storageKey 存入各业务表 files 元数据
 */
export interface UploadedFile { storageKey: string; fileName: string; mimeType: string; sizeBytes: number }
export const apiUploadFile = async (file: File | Blob, fileName?: string, meta?: { electionFiefId?: string; sourceType?: string }): Promise<UploadedFile> => {
  const fd = new FormData();
  fd.append('file', file, fileName || (file as File).name || 'file');
  if (meta?.electionFiefId) fd.append('electionFiefId', meta.electionFiefId);
  if (meta?.sourceType) fd.append('sourceType', meta.sourceType);
  return http.post('/files/upload', fd) as Promise<UploadedFile>;
};
export const apiFileUrl = (key: string) => `${http.defaults.baseURL}/files/${key}`;
export const apiOrgs = async () => {
  const list = await http.get('/auth/organizations') as Array<{ id: string; slug: string; name: string; org_type: 'village' | 'community'; status: string }>;
  return list.map((org) => ({ orgId: org.id, name: org.name, type: org.slug, orgType: org.org_type, status: org.status }));
};
export const apiHealth = () => http.get('/health') as Promise<{ db: string; today?: string }>;

// ── 读 ────────────────────────────────────────────────
export const getElections = () => http.get('/api/elections') as Promise<Election[]>;
export const getStages = (electionUuid: string) => http.get(`/api/elections/${electionUuid}/stages`) as Promise<Stage[]>;
export const getAnnouncements = (elId?: string) =>
  http.get('/api/announcements', { params: elId ? { electionId: elId } : {} }) as Promise<Announcement[]>;
export const getCandidates = () => http.get('/api/candidates') as Promise<Candidate[]>;
export const getMaterials = async () => {
  const rows = await http.get('/admin/materials') as any[];
  return (rows || []).map((m: any) => ({
    id: m.id,
    orgId: m.organization_id,
    elId: m.election_fief_id,
    matType: '组织推荐',
    matStatus: m.status === 'submitted' ? 'submitted' : m.status,
    matPositionId: '—',
    matCandidateId: m.candidate_id,
    matSubmitter: m.submitter_name || m.title || '—',
    matSubmitterPhone: m.submitter_phone || '',
    matSubmitTime: m.submitted_at,
    matReviewTime: m.reviewed_at,
    matReviewer: m.reviewed_by || '',
    matReviewComment: m.review_note || '',
    matStage: m.fief_name || '',
    matNote: m.description || '',
    matFiles: (m.files || []).map((f: any) => ({ name: f.file_name, url: apiFileUrl(f.storage_key) })),
  })) as Material[];
};
export const getPositions = () => http.get('/api/positions') as Promise<Position[]>;
export const getNotifications = () => http.get('/api/notifications');
export const getRoster = () => http.get('/api/roster');
// getResults 已删除：甲方 A-002 禁止投票/得票概念
export const getProposals = () => http.get('/admin/proposals') as Promise<Proposal[]>;
export interface ArchiveItem { id: string; orgId: string; elId: string; archSourceType: string; archDisplayName: string; archVisibility: string; archFileVersion?: string; storageKey?: string }
export const getArchives = () => http.get('/api/archives') as Promise<ArchiveItem[]>;
export const getDashboardAlerts = () => http.get('/api/dashboard/alerts') as Promise<Array<{ level: string; text: string }>>;

// ── 写（映射到后端 /admin/*）─────────────────────────────
export const publishAnnouncement = (id: string) => http.post(`/admin/announcements/${id}/publish`);
export const createAnnouncement = (draft: { elId: string; annTitle: string; annContent?: string; templateCode?: string }) =>
  http.post('/admin/announcements', { electionFiefId: draft.elId, title: draft.annTitle, body: draft.annContent, templateCode: draft.templateCode });
export const reviewMaterial = (id: string, status: 'approved' | 'rejected', comment?: string) =>
  http.patch(`/admin/materials/${id}/review`, { status, note: comment });
// setCandidateResult 已删除：甲方 A-002 禁止投票/得票概念
// 候选人轮次审核（映射到后端 /admin/candidates/:id/reviews）
export const putCandidateRound = (id: string, round: 'R1' | 'R2' | 'R3' | 'R4', decision: 'approved' | 'rejected', note?: string) =>
  http.post(`/admin/candidates/${id}/reviews`, { round, decision, note }) as Promise<{ id: string; current_round: string; status: string }>;
// sendReviewMail 已删除：后端无 SMTP 邮件接口
// 内推手工新增（组织推荐）：staff 代建材料
export const createMaterial = (draft: { name: string; phone: string; positionId?: string; note?: string; orgId?: string; elId?: string }) =>
  http.post('/admin/materials', { electionFiefId: draft.elId, phone: draft.phone, name: draft.name, title: draft.positionId ? `${draft.positionId}报名材料` : undefined, description: draft.note }) as Promise<{ id: string; matStatus: string; matType: string; matPositionId?: string }>;
// v6.2 追加附件（代传）：先统一上传拿 storageKey，再关联到材料；上传按归档目录结构落盘（归属地/届/材料）
export const appendMaterialFile = async (matId: string, file: File, elId?: string) => {
  const up = await apiUploadFile(file, undefined, { electionFiefId: elId, sourceType: 'material' });
  return http.post(`/admin/materials/${matId}/file`, { storageKey: up.storageKey, fileName: up.fileName, mimeType: up.mimeType, sizeBytes: up.sizeBytes }) as Promise<{ id: string }>;
};
// generateStages 已删除：pipeline 提案审核通过后自动生成封地+日程+岗位+公告

// ── 提案：创建 / 审批联动 / 附件（真实落库，刷新不丢）─────
// 创建提案（映射到后端 /admin/proposals：term/unit 后端自动回填；岗位名/名额对齐）
export const createProposal = async (draft: { title: string; method: string; electionDate: string; posts: ProposalPost[]; orgId?: string; report?: string }) => {
  const r = (await http.post('/admin/proposals', {
    organizationId: draft.orgId,
    name: draft.title,
    dDay: draft.electionDate,
    positions: draft.posts.map((p) => ({ name: p.position, quota: p.count })),
  })) as any;
  return { id: r.id, elId: r.term_id, title: r.name, status: r.status };
};
export const updateProposal = (id: string, draft: { title: string; method: string; electionDate: string; posts: ProposalPost[]; report?: string }) =>
  http.patch(`/admin/proposals/${id}`, {
    name: draft.title,
    dDay: draft.electionDate,
    positions: draft.posts.map((p) => ({ name: p.position, quota: p.count })),
  }) as Promise<{ id: string; status: string }>;
// 审批（通过→后端事务内生成活动+日程+岗位+公告草稿）；返回字段映射为前端兼容名
export const reviewProposal = async (id: string, action: 'approve' | 'reject', comment?: string) => {
  const r = (await http.post(`/admin/proposals/${id}/review`, { decision: action === 'approve' ? 'approved' : 'rejected', note: comment })) as any;
  return { ...r, elId: r.fiefId, stagesGenerated: r.stages, positionsGenerated: r.positions, announcementsGenerated: r.announcements };
};
export const uploadProposalFile = (proposalId: string, file: File) => {
  const fd = new FormData(); fd.append('file', file);
  return http.post(`/admin/proposals/${proposalId}/file`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
};
// AnnouncementPatch 已删除：updateAnnouncement 改用内联类型
export const updateAnnouncement = (id: string, patch: { annTitle?: string; annContent?: string }) =>
  http.patch(`/admin/announcements/${id}`, { title: patch.annTitle, body: patch.annContent });
// 公告附件真实上传（每份公告独立目录，切换公告不写死）
export const uploadAnnouncementFile = (id: string, file: File) => {
  const fd = new FormData(); fd.append('file', file);
  return http.post(`/admin/announcements/${id}/file`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }) as Promise<{ id: string; file: string; size: number }>;
};
// 岗位附件真实上传
export const uploadPositionFile = (posId: string, file: File) => {
  const fd = new FormData(); fd.append('file', file);
  return http.post(`/admin/positions/${posId}/file`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }) as Promise<{ id: string; file: string; size: number }>;
};

// ── 后台账号管理（D-013：仅 platform_admin；隐藏解锁页/人员管理共用）────────
export interface AdminAccount {
  id: string; orgId: string; orgName?: string; name: string; phone: string;
  status: string; note?: string; createdAt?: string; roleKey?: string;
}
export interface PresetAccountRow { name?: string; phone: string; roleKey: 'sub_admin' | 'editor' | 'reviewer'; password?: string }
export interface PresetResult { created: string[]; updated: string[]; skipped: { phone: string; reason: string }[]; orgId: string; orgName: string }
// 账号列表（可按归属地筛）
export const adminListAccounts = (orgId?: string) =>
  http.get('/admin/accounts', { params: orgId ? { orgId } : {} }) as Promise<AdminAccount[]>;
// 批量预设账号（需解锁码，后端校验 123456 / env.UNLOCK_CODE）
export const adminPresetAccounts = (unlockCode: string, orgId: string, accounts: PresetAccountRow[]) =>
  http.post('/admin/accounts/preset', { unlockCode, orgId, accounts }) as Promise<PresetResult>;
// 启用/停用
export const adminSetAccountStatus = (id: string, status: 'active' | 'disabled') =>
  http.put(`/admin/accounts/${id}/status`, { status });
// 重置密码（默认 123456）
export const adminResetPassword = (id: string, password?: string) =>
  http.put(`/admin/accounts/${id}/reset-password`, { password: password || '123456' });

// ── 小程序端 ───────────────────────────────────────────
export const mpLogin = (phone: string) => http.post('/api/mp/login', { phone });
export const mpRegister = (phone: string, orgId: string, name?: string) => http.post('/api/mp/register', { phone, orgId, name });

// ── 角色权限（王权中枢 · 接后端 roles/role_permissions 真表）─────────────
export interface RoleDTO { key: string; name: string; is_staff: boolean; is_system: boolean; permissions: string[] }
export interface PermissionDTO { permission: string; description?: string | null }
export const getRoles = () => http.get('/admin/roles') as Promise<RoleDTO[]>;
export const getRolePermissions = () => http.get('/admin/role-permissions') as Promise<PermissionDTO[]>;
export const createRole = (d: { key: string; name: string; isStaff?: boolean; permissions?: string[] }) =>
  http.post('/admin/roles', d) as Promise<{ key: string }>;
export const updateRole = (key: string, patch: { name?: string; permissions?: string[] }) =>
  http.patch(`/admin/roles/${key}`, patch) as Promise<{ key: string }>;
export const deleteRole = (key: string) => http.delete(`/admin/roles/${key}`) as Promise<{ ok: boolean; key: string }>;

// ── webhook 通知订阅（企业微信/飞书机器人）─────────────
export interface WebhookSub {
  id: string;
  organization_id: string;
  name: string;
  channel: 'wecom' | 'feishu' | 'plain';
  url: string;
  mobile?: string | null;
  active: boolean;
  created_at?: string;
}
export const getWebhookSubs = () => http.get('/admin/webhook-subscriptions') as Promise<WebhookSub[]>;
export const createWebhookSub = (d: { name: string; channel: 'wecom' | 'feishu' | 'plain'; url: string; mobile?: string }) =>
  http.post('/admin/webhook-subscriptions', d) as Promise<WebhookSub>;
export const updateWebhookSub = (
  id: string,
  patch: Partial<Pick<WebhookSub, 'name' | 'url' | 'mobile' | 'active'>>,
) => http.patch(`/admin/webhook-subscriptions/${id}`, patch) as Promise<WebhookSub>;
export const deleteWebhookSub = (id: string) => http.delete(`/admin/webhook-subscriptions/${id}`) as Promise<{ ok: boolean }>;
export const testWebhookSub = (id: string) =>
  http.post(`/admin/webhook-subscriptions/${id}/test`, {}) as Promise<{ ok: boolean; status?: number }>;

// ── 本地登录态 ─────────────────────────────────────────
export const currentUser = (): LoginUser | null => {
  try { return JSON.parse(localStorage.getItem('cxq_user') || 'null'); } catch { return null; }
};
export const currentToken = () => localStorage.getItem('cxq_token') || '';
export const changePassword = (oldPassword: string, newPassword: string) =>
  http.post('/auth/change-password', { oldPassword, newPassword }) as Promise<{ ok: boolean }>;
export const saveLogin = (token: string, user: LoginUser) => {
  localStorage.setItem('cxq_token', token);
  localStorage.setItem('cxq_user', JSON.stringify(user));
  localStorage.setItem('election_login', JSON.stringify({ orgId: user.orgId, orgLabel: user.orgName || user.orgId, phone: user.phone, role: user.role }));
};
export const clearLogin = () => {
  localStorage.removeItem('cxq_token');
  localStorage.removeItem('cxq_user');
};

// ── 工具：日期与倒计时（与后端 D 日引擎同口径）─────────
export const daysBetween = (a: string, b: string) =>
  Math.round((new Date(a + 'T00:00:00').getTime() - new Date(b + 'T00:00:00').getTime()) / 86400000);
// 本地日期（不能用 toISOString：UTC+8 凌晨会回退到前一天，与后端 D 日本地口径对齐）
export const todayStr = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};
