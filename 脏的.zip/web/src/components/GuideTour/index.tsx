import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'tdesign-react';
import { currentUser, LoginUser, getMaterials, todayStr } from 'services/electionApi';
import { getActivities } from 'utils/electionStore';

const DONE_KEY = 'cxq_guide_done_v1';

/** 业务角色 → 中文（与后端 roles/account_roles 对齐） */
const roleLabel = (u: LoginUser): string => {
  if (u.role === 'admin' || u.roles === 'platform_admin') return '平台超管';
  const map: Record<string, string> = {
    platform_admin: '平台超管',
    sub_admin: '村/社区子管理',
    operator: '经办/书记',
    editor: '运营编辑',
    reviewer: '审核员',
    candidate: '参选人',
  };
  const keys = u.roleKeys || [];
  const hit = keys.map((k) => map[k]).filter(Boolean);
  return hit[0] || (u.roles && map[u.roles]) || map[u.role] || '工作人员';
};

/** 材料上报阶段 stageKey（候选人提名启动/延续，此时材料审核中） */
const MATERIAL_STAGE_KEYS = ['D-15', 'D-14'];

const addDays = (dateStr: string, offset: number): string => {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + offset);
  const mm = String(dt.getMonth() + 1).padStart(2, '0');
  const dd = String(dt.getDate()).padStart(2, '0');
  return `${dt.getFullYear()}-${mm}-${dd}`;
};

interface Task {
  activityId: number;
  name: string;
  date: string;
  work: string;
}

interface Step {
  title: string;
  body: React.ReactNode;
}

/**
 * 登录后欢迎工作台（D-014）：第一屏为数据驱动「当前任务 + 近 7 天任务 + 材料待审」，
 * 快捷跳转日程/材料；后续为换届主线教学。localStorage 记忆，只弹一次。
 */
export default function GuideTour() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [idx, setIdx] = useState(0);
  const [user, setUser] = useState<LoginUser | null>(null);
  const [cur, setCur] = useState<Task | null>(null);
  const [next, setNext] = useState<Task | null>(null);
  const [soon, setSoon] = useState<Task[]>([]);
  const [pending, setPending] = useState(0);

  useEffect(() => {
    const u = currentUser();
    if (!u) return; // 未登录不弹
    if (localStorage.getItem(DONE_KEY) === '1') return;
    setUser(u);
    const t = setTimeout(() => setOpen(true), 350); // 等主框架渲染稳
    return () => clearTimeout(t);
  }, []);

  // 工作台数据：当前活动 → 进行中阶段 + 近7天任务 + 材料待审数
  useEffect(() => {
    if (!open) return;
    const today = todayStr();
    const acts = getActivities();
    if (!acts?.length) return;
    const act = acts.find((a) => a.status === 'ongoing') || acts[0];
    if (!act) return;
    const s = act.stages || [];
    const curS = s.find((x) => x.date <= today && x.endDate >= today);
    if (curS) setCur({ activityId: act.id, name: curS.name, date: curS.date, work: curS.work || '' });
    setSoon(
      s
        .filter((x) => x.date <= addDays(today, 7) && x.endDate >= today)
        .sort((a, b) => (a.date < b.date ? -1 : 1))
        .slice(0, 5)
        .map((x) => ({ activityId: act.id, name: x.name, date: x.date, work: x.work || '' })),
    );
    // 兜底：无进行中/7天任务时，展示最近一个未来阶段（未到筹备期也好看且真实）
    const future = s.filter((x) => x.date > today).sort((a, b) => (a.date < b.date ? -1 : 1));
    if (future[0]) setNext({ activityId: act.id, name: future[0].name, date: future[0].date, work: future[0].work || '' });
    if (curS && MATERIAL_STAGE_KEYS.includes(curS.key)) {
      getMaterials()
        .then((rows) => setPending((rows || []).filter((m) => m.matStatus === 'submitted').length))
        .catch(() => {});
    }
  }, [open]);

  const go = (path: string) => {
    close();
    navigate(path);
  };

  const close = () => {
    setOpen(false);
    localStorage.setItem(DONE_KEY, '1');
  };

  if (!open || !user) return null;

  const workbench: Step = {
    title: `欢迎，${user.name || user.phone}`,
    body: (
      <div className="gt-wb">
        <p className="gt-wb-meta">归属地：<b>{user.orgName || user.orgId}</b> ｜ 角色：<b>{roleLabel(user)}</b></p>
        {cur && (
          <div className="gt-task gt-task-cur" role="button" tabIndex={0} onClick={() => go(`/election/activity/${cur.activityId}`)}>
            <span className="gt-tag cur">当前任务</span>
            <b>{cur.name}</b>
            <span className="gt-go">去日程 ›</span>
          </div>
        )}
        {!cur && next && (
          <div className="gt-task gt-task-cur" role="button" tabIndex={0} onClick={() => go(`/election/activity/${next.activityId}`)}>
            <span className="gt-tag cur">即将开始</span>
            <b>{next.name}（{next.date}）</b>
            <span className="gt-go">去日程 ›</span>
          </div>
        )}
        {pending > 0 && (
          <div className="gt-task gt-task-mat" role="button" tabIndex={0} onClick={() => go('/election/materials')}>
            <span className="gt-tag mat">材料待审</span>
            <b>{pending} 份新提交材料待审核</b>
            <span className="gt-go">去材料管理 ›</span>
          </div>
        )}
        {soon.length > 0 && (
          <div className="gt-soon">
            <div className="gt-soon-title">近期任务（7 天内）</div>
            {soon.map((t) => (
              <div key={t.date + t.name} className="gt-row" role="button" tabIndex={0} onClick={() => go(`/election/activity/${t.activityId}`)}>
                <span className="gt-date">{t.date}</span>
                <b className="gt-name">{t.name}</b>
                <span className="gt-work">{t.work}</span>
                <span className="gt-go">›</span>
              </div>
            ))}
          </div>
        )}
        {!cur && !next && soon.length === 0 && <p className="gt-sub">暂无进行中或近 7 天日程任务。</p>}
      </div>
    ),
  };

  const steps: Step[] = [
    workbench,
    {
      title: '一条主线走完换届',
      body: (
        <ol className="gt-flow">
          <li><b>① 提案审批</b>：新建提案，填选举日(D-day)、岗位、说明，提交审核</li>
          <li><b>② 审核通过</b>：系统自动生成这一届的日程表、公告草稿、岗位记录</li>
          <li><b>③ 小编工作台</b>：唯一编辑口，改公告、选发布方式、发布</li>
          <li><b>④ 材料 / 候选人</b>：参选人小程序交材料，线下审核后在这里回填结果</li>
          <li><b>⑤ 归档</b>：提案、公告、材料、结果按届归档</li>
        </ol>
      ),
    },
    {
      title: '唯一编辑口，避免两处打架',
      body: (
        <>
          <p>公告内容<b>只在「活动列表 → 小编工作台」编辑和预览</b>。</p>
          <p>「公告通知 → 公告记录」只负责<b>记录发没发</b>，不再提供第二处编辑，保证只有一个真相。</p>
          <p className="gt-sub">同一天发多份公告时，在工作台逐份切换编辑，每份各自带下载附件。</p>
        </>
      ),
    },
    {
      title: 'D 日怎么算 & 线下环节',
      body: (
        <>
          <p><b>D-day</b> = 选举正式日；<b>D-N</b> = 提前 N 天；<b>D+N</b> = 之后 N 天，日程自动排。</p>
          <p>材料审核、候选人资格审查是<b>线下人工</b>完成后，回到后台「材料管理 / 候选人管理」回填结果即可。</p>
          <p className="gt-sub">遇到问题随时联系平台管理员。祝顺利完成换届！</p>
        </>
      ),
    },
  ];
  const step = steps[idx];
  const last = idx === steps.length - 1;

  return (
    <div className="gt-mask">
      <div className="gt-card" role="dialog" aria-label="欢迎工作台">
        <div className="gt-head">
          <span className="gt-step-no">{idx + 1} / {steps.length}</span>
          <button className="gt-skip" onClick={close} type="button">跳过</button>
        </div>
        <h3 className="gt-title">{step.title}</h3>
        <div className="gt-body">{step.body}</div>
        <div className="gt-dots">
          {steps.map((_, i) => (
            <span key={i} className={`gt-dot ${i === idx ? 'on' : ''}`} />
          ))}
        </div>
        <div className="gt-footer">
          {idx > 0 && <Button variant="text" onClick={() => setIdx(idx - 1)}>上一步</Button>}
          <div style={{ flex: 1 }} />
          {!last ? (
            <Button theme="primary" onClick={() => setIdx(idx + 1)}>下一步</Button>
          ) : (
            <Button theme="primary" onClick={close}>我知道了，开始办公</Button>
          )}
        </div>
      </div>
      <style>{`
        .gt-mask{position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.42);display:flex;align-items:center;justify-content:center;padding:24px;}
        .gt-card{width:560px;max-width:100%;max-height:86vh;overflow:auto;background:#fff;border-radius:14px;box-shadow:0 18px 48px rgba(0,0,0,.22);padding:22px 24px;}
        .gt-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;}
        .gt-step-no{font-size:12px;color:#8a94a6;background:#f2f4f8;border-radius:10px;padding:2px 10px;}
        .gt-skip{border:none;background:none;color:#8a94a6;cursor:pointer;font-size:13px;}
        .gt-skip:hover{color:#4a5568;}
        .gt-title{margin:6px 0 12px;font-size:18px;color:#1f2329;}
        .gt-body{font-size:14px;color:#3d4350;line-height:1.75;}
        .gt-body p{margin:6px 0;}
        .gt-sub{color:#8a94a6;font-size:12.5px;}
        .gt-flow{margin:4px 0;padding-left:0;list-style:none;}
        .gt-flow li{padding:7px 10px;margin:6px 0;background:#f7f9fc;border-radius:8px;border-left:3px solid #9EACEA;}
        .gt-dots{display:flex;gap:6px;margin:14px 0 4px;}
        .gt-dot{width:7px;height:7px;border-radius:50%;background:#dde2ea;}
        .gt-dot.on{background:#6b7fb8;width:18px;border-radius:4px;}
        .gt-footer{display:flex;align-items:center;margin-top:8px;}
        .gt-wb-meta{margin:0 0 10px;color:#3d4350;}
        .gt-task{display:flex;align-items:center;gap:8px;padding:11px 12px;margin:8px 0;border-radius:10px;cursor:pointer;transition:transform .06s;}
        .gt-task:active{transform:scale(.99);}
        .gt-task-cur{background:linear-gradient(135deg,rgba(158,172,234,.18),rgba(158,172,234,.30));border:1px solid rgba(158,172,234,.5);}
        .gt-task-mat{background:linear-gradient(135deg,rgba(234,167,178,.16),rgba(234,167,178,.30));border:1px solid rgba(234,167,178,.5);}
        .gt-tag{font-size:12px;border-radius:6px;padding:2px 8px;color:#fff;flex:none;}
        .gt-tag.cur{background:#6b7fb8;}
        .gt-tag.mat{background:#d97b8c;}
        .gt-go{margin-left:auto;color:#6b7fb8;font-size:13px;flex:none;}
        .gt-soon{margin-top:12px;}
        .gt-soon-title{font-size:13px;color:#8a94a6;margin-bottom:6px;}
        .gt-row{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;cursor:pointer;}
        .gt-row:hover{background:#f7f9fc;}
        .gt-date{font-size:12px;color:#8a94a6;flex:none;font-variant-numeric:tabular-nums;}
        .gt-name{flex:none;}
        .gt-work{font-size:12.5px;color:#8a94a6;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1;}
      `}</style>
    </div>
  );
}
