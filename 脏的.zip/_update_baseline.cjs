const fs = require('fs');
const p = '3_案件取证  只有这里的可相信  必看 每个字/14_系统认知基线-脱稿制.md';
let t = fs.readFileSync(p, 'utf8');
const oldStart = '## 11. 当前差距与下一步';
const oldEnd = '## 12. 一口铁律';
const i1 = t.indexOf(oldStart);
const i2 = t.indexOf(oldEnd);
if (i1 < 0 || i2 < 0) throw new Error('markers not found: ' + i1 + ',' + i2);
const newSection = `## 11. 当前差距与下一步（2026-09-04 最新状态）

> **进度（2026-09-04 晚）：数据库已从 Neon 迁回本机 PostgreSQL（backend_new）；后端 pipeline 27/27 端到端测试通过；19 套公告模板按甲方 DOCX 原文重建；web 白屏修复；登录链路打通（138 账号+归属地+密码 200 返回 token）。**

**真实演示数据（本地库，以库内实际为准）**：
- 演示村 orgId=e1a318cf-dbd7-4f6c-ab2e-3c60d68affae（slug demo-village，village）
- 演示社区 orgId=44365f42-164c-4ea6-9f79-3363a609dd71（slug demo-community，community）
- 平台超管：13800000000 / 123456 / platform_admin
- 演示村：13800000001 sub_admin / 13800000002 editor / 13800000003 reviewer
- 演示社区：13800000011 sub_admin / 13800000012 editor / 13800000013 reviewer
- 参选人（小程序）：13800000021/22/23、13900000001（candidate，不入后台）
- 所有密码已重置为 123456（2026-09-04）
- 角色枚举：platform_admin / sub_admin / editor / reviewer / candidate（五角色，不是 org_admin/operator）

**后端已落地**：
1. 角色枚举收敛五角色 + roles/role_permissions（44 权限点，可配置）
2. POST /admin/accounts 超管开账号 + /auth/register 收口 candidate-only
3. 村/居两版 stage_templates（28 条）+ 19 套公告模板（16 条自动排期）
4. 提案 pipeline：POST /admin/proposals 创建 → POST /admin/proposals/:id/review 审核通过 → 单事务内自动生成封地+14阶段+4岗位+16条预排公告（社区版称谓替换）；27/27 测试通过
5. CORS 全放行 origin:true；端口 3100

**前端（web）已修复**：
1. 移除死依赖 @honkhonk/vite-plugin-svgr/vite-plugin-mock/mockjs（与 vite5 冲突）
2. 白屏根因：?component SVG 导入无插件转换 → 已用内联 svgAsComponent 插件（vite.config.js）替代
3. 登录页归属地下拉：TDesign Select 不识别扁平 group 字段 → 改为简单 {label,value} 格式
4. vite proxy 从旧 8080 改为 3100（/api /auth /admin /candidate 全转发）
5. 登录链路打通：归属地+账号+密码 → 200 token

**前端（web）待办**：
1. electionApi.ts 业务接口仍为旧 /api/*（约 20 个），需映射到 backend-new 真实路由
2. 清假数据源：main.tsx/liveSync.ts/electionStore.ts/noticeStore.ts/chart.ts/roleStore.ts/host.ts/Detail consts.ts
3. 权限后端化：登录返回 role+role_permissions，禁止 localStorage 切角色
4. schema.sql 需回写本轮新增表（election_proposals/positions/at_sched_offset/scheduled_for/stage_key）

**验收闸门**：真实浏览器登录 → 村/居各自日程正确 → 角色权限隔离生效 → 提案审核通过自动生成全套 → 公告模板与 DOCX 逐字一致。

`;
t = t.slice(0, i1) + newSection + t.slice(i2);
fs.writeFileSync(p, t, 'utf8');
console.log('§11 已更新，文件长度', t.length);
