# 村居换届系统 本地服务守护（循环版，供工作会话后台托管）
# 用法：powershell -ExecutionPolicy Bypass -File supervisord.ps1
while ($true) {
  # 后端 3100
  $b = Get-NetTCPConnection -LocalPort 3100 -State Listen -ErrorAction SilentlyContinue
  if (-not $b) {
    try { Start-Process node -ArgumentList '--env-file=.env','--import','tsx/esm','src/server.ts' -WorkingDirectory 'K:\3\3\backend-new' -WindowStyle Hidden } catch {}
    Start-Sleep -Seconds 3
  }
  # 前端 3003
  $w = Get-NetTCPConnection -LocalPort 3003 -State Listen -ErrorAction SilentlyContinue
  if (-not $w) {
    try { Start-Process cmd -ArgumentList '/c','npx vite --port 3003' -WorkingDirectory 'K:\3\3\web' -WindowStyle Hidden } catch {}
    Start-Sleep -Seconds 3
  }
  Start-Sleep -Seconds 5
}
